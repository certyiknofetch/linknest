(function initLinkNestClient(globalScope) {
  const extensionApi =
    typeof browser !== 'undefined' && browser.runtime && browser.storage
      ? browser
      : chrome;

  let refreshInFlight = null;

  async function getStorage(keys) {
    return extensionApi.storage.local.get(keys);
  }

  async function setStorage(data) {
    return extensionApi.storage.local.set(data);
  }

  async function removeStorage(keys) {
    return extensionApi.storage.local.remove(keys);
  }

  async function hashString(str) {
    const encoder = new TextEncoder();
    const data = encoder.encode(String(str || ''));
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((value) => value.toString(16).padStart(2, '0')).join('');
  }

  async function getServerUrl() {
    const { serverUrl } = await getStorage(['serverUrl']);
    if (!serverUrl) {
      throw new Error('Server URL not configured. Please set it in Settings.');
    }

    try {
      const parsed = new URL(serverUrl);
      const isLocalhost = parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1';
      if (!isLocalhost && parsed.protocol !== 'https:') {
        throw new Error('Insecure server URL. Please use HTTPS.');
      }
      return serverUrl;
    } catch (error) {
      throw error?.message ? error : new Error('Invalid server URL configuration.');
    }
  }

  async function parseJsonResponse(response) {
    try {
      return await response.json();
    } catch {
      return {};
    }
  }

  async function refreshAccessToken() {
    if (refreshInFlight) {
      return refreshInFlight;
    }

    refreshInFlight = (async () => {
      const serverUrl = await getServerUrl();
      const { refreshToken } = await getStorage(['refreshToken']);
      const payload = refreshToken ? { refreshToken } : {};

      const response = await fetch(`${serverUrl}/api/auth/refresh`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await parseJsonResponse(response);
      if (!response.ok) {
        throw new Error(data.error || 'Session refresh failed. Please log in again.');
      }

      const nextAccessToken = data.accessToken || data.token;
      const nextRefreshToken = data.refreshToken || refreshToken;
      if (!nextAccessToken) {
        throw new Error('Refresh response did not include an access token.');
      }

      // Server-side HttpOnly cookies own both access + refresh token lifecycle.
      if (nextAccessToken || nextRefreshToken || refreshToken) {
        await removeStorage(['token', 'refreshToken']);
      }

      return nextAccessToken;
    })().finally(() => {
      refreshInFlight = null;
    });

    return refreshInFlight;
  }

  async function apiRequest(endpoint, options = {}, config = {}) {
    const { allowRefresh = true, onSessionExpired = null } = config;
    const serverUrl = await getServerUrl();
    const { token } = await getStorage(['token']);

    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    };

    const response = await fetch(`${serverUrl}/api${endpoint}`, {
      ...options,
      credentials: 'include',
      headers,
    });

    const isAuthEndpoint = endpoint.startsWith('/auth/');
    if (response.status === 401 && allowRefresh && !isAuthEndpoint) {
      try {
        await refreshAccessToken();
        return apiRequest(endpoint, options, { ...config, allowRefresh: false });
      } catch {
        await removeStorage(['token', 'refreshToken', 'user']);
        if (typeof onSessionExpired === 'function') {
          await onSessionExpired();
        }
        throw new Error('Session expired. Please log in again.');
      }
    }

    const data = await parseJsonResponse(response);

    if (!response.ok) {
      throw new Error(data.error || `Request failed (${response.status})`);
    }

    return data;
  }

  async function verifyServerUrlBinding() {
    const { boundServerUrlHash, serverUrl } = await getStorage(['boundServerUrlHash', 'serverUrl']);
    if (!boundServerUrlHash || !serverUrl) return true;
    const currentHash = await hashString(serverUrl);
    return currentHash === boundServerUrlHash;
  }

  globalScope.LinkNestClient = Object.freeze({
    getStorage,
    setStorage,
    removeStorage,
    hashString,
    getServerUrl,
    parseJsonResponse,
    refreshAccessToken,
    apiRequest,
    verifyServerUrlBinding,
  });
})(typeof self !== 'undefined' ? self : window);
