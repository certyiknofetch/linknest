// ===== Bookmark Change Listeners =====

let syncDebounceTimer = null;
let isApplyingRemoteChanges = false;
let isSyncInProgress = false;

function debouncedSync() {
  if (isApplyingRemoteChanges || isSyncInProgress) {
    return;
  }

  if (syncDebounceTimer) clearTimeout(syncDebounceTimer);
  syncDebounceTimer = setTimeout(async () => {
    if (isSyncInProgress) return;
    const { autoSync, user } = await getStorage(['autoSync', 'user']);
    if (autoSync !== false && user) {
      try {
        await performSync();
        console.log('LinkNest: Auto-sync completed after bookmark change');
      } catch (err) {
        console.warn('LinkNest: Auto-sync failed:', err.message);
      }
    }
  }, 5000);
}

api.bookmarks.onCreated.addListener(() => debouncedSync());
api.bookmarks.onRemoved.addListener(() => debouncedSync());
api.bookmarks.onChanged.addListener(() => debouncedSync());
api.bookmarks.onMoved.addListener(() => debouncedSync());

// ===== Periodic Sync via Alarms =====

async function setupAlarm(settings) {
  // Clear existing alarm
  await api.alarms.clear('linknest-sync');

  const autoSync = settings?.autoSync !== false;
  const interval = parseInt(settings?.syncInterval) || DEFAULT_SYNC_INTERVAL;

  if (autoSync) {
    api.alarms.create('linknest-sync', {
      periodInMinutes: interval,
    });
    console.log(`LinkNest: Sync alarm set for every ${interval} minutes`);
  }
}

api.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'linknest-sync') {
    if (isSyncInProgress) return;
    const { user } = await getStorage(['user']);
    if (user) {
      try {
        await performSync();
        console.log('LinkNest: Periodic sync completed');
      } catch (err) {
        console.warn('LinkNest: Periodic sync failed:', err.message);
      }
    }
  }
});

// ===== Extension Install / Startup =====

api.runtime.onInstalled.addListener(async (details) => {
  console.log('LinkNest extension installed/updated:', details?.reason);
  const settings = await getStorage(['autoSync', 'syncInterval']);
  await setupAlarm(settings);
});

api.runtime.onStartup.addListener(async () => {
  console.log('LinkNest extension started');
  const settings = await getStorage(['autoSync', 'syncInterval']);
  await setupAlarm(settings);
});
