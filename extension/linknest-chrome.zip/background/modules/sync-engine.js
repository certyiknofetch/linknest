// ===== Sync Engine =====

function buildLocalBookmarkLookup(localBookmarks) {
  const byHash = buildBookmarkMap(localBookmarks);
  const byUrl = new Map();

  for (const bookmark of localBookmarks) {
    const url = bookmark?.url;
    if (!url) continue;
    if (!byUrl.has(url)) {
      byUrl.set(url, []);
    }
    byUrl.get(url).push(bookmark);
  }

  return { byHash, byUrl };
}

function pickUrlFallbackBookmark(serverBookmark, lookup, usedLocalIds) {
  const candidates = (lookup.byUrl.get(serverBookmark.url) || []).filter(
    (candidate) => candidate?.localId && !usedLocalIds.has(candidate.localId)
  );
  if (candidates.length === 0) return null;

  // Safe fallback when URL is unique on local side.
  if (candidates.length === 1) {
    return candidates[0];
  }

  // When duplicates exist, only match if folder path is uniquely identifiable.
  const targetFolderPath = serverBookmark?.folderPath || '';
  const sameFolderCandidates = candidates.filter(
    (candidate) => (candidate.folderPath || '') === targetFolderPath
  );
  if (sameFolderCandidates.length === 1) {
    return sameFolderCandidates[0];
  }

  return null;
}

function resolveLocalBookmarkForServer(serverBookmark, lookup, usedLocalIds) {
  const exactHashMatch = lookup.byHash.get(serverBookmark.bookmarkHash);
  if (exactHashMatch?.localId && !usedLocalIds.has(exactHashMatch.localId)) {
    return exactHashMatch;
  }

  return pickUrlFallbackBookmark(serverBookmark, lookup, usedLocalIds);
}

function safeBookmarkArray(response) {
  return Array.isArray(response?.bookmarks) ? response.bookmarks : [];
}

/**
 * Full bidirectional sync
 * 1. Read local bookmarks
 * 2. Push to server
 * 3. Server returns merged result
 * 4. Apply missing bookmarks locally
 */
async function performSync() {
  if (isSyncInProgress) {
    throw new Error('Sync already in progress.');
  }
  isSyncInProgress = true;

  try {
    const urlValid = await verifyServerUrlBinding();
    if (!urlValid) {
      throw new Error('Server URL has changed since login. Please log out and log in again.');
    }

    const { user, browserName, lastSyncTime, lastLocalBookmarkHashes } = await getStorage([
      'user',
      'browserName',
      'lastSyncTime',
      'lastLocalBookmarkHashes',
    ]);

    if (!user) throw new Error('Not authenticated');

    const { bookmarks: localBookmarks, skippedInvalidUrls, skippedInvalidBookmarkUrls } = await getLocalBookmarksWithStats();
    const deletedBookmarkHashes = getDeletedHashes(lastLocalBookmarkHashes, localBookmarks);

    const bookmarkChunks = chunkArray(localBookmarks, MAX_BOOKMARKS_PER_SYNC_CHUNK);
    const deletedChunks = chunkArray(deletedBookmarkHashes, MAX_BOOKMARKS_PER_SYNC_CHUNK);
    const totalBatches = Math.max(bookmarkChunks.length || 0, deletedChunks.length || 0, 1);
    const shouldChunk = totalBatches > 1;
    let pushCreated = 0;
    let pushUpdated = 0;
    let pushDeleted = 0;
    let lastServerTime = new Date().toISOString();

    if (!shouldChunk) {
      const response = await apiRequest('/bookmarks/sync', {
        method: 'POST',
        body: JSON.stringify({
          bookmarks: localBookmarks,
          deletedBookmarkHashes,
          lastSyncTime: lastSyncTime || null,
          browserName: browserName || 'Unknown',
          syncMode: 'full',
        }),
      });

      const lookup = buildLocalBookmarkLookup(localBookmarks);
      const usedLocalIds = new Set();
      let pulled = 0;
      let remoteUpdated = 0;
      let removed = 0;
      let applyErrors = 0;

      isApplyingRemoteChanges = true;
      try {
        for (const serverBm of safeBookmarkArray(response)) {
          try {
            if (!isSyncableHttpUrl(serverBm.url)) {
              applyErrors += 1;
              continue;
            }
            const localBookmark = resolveLocalBookmarkForServer(serverBm, lookup, usedLocalIds);
            if (localBookmark?.localId) {
              usedLocalIds.add(localBookmark.localId);
            }
            const result = await applyServerBookmark(localBookmark, serverBm);
            pulled += result.created;
            remoteUpdated += result.updated;
            removed += result.deleted;
          } catch (err) {
            applyErrors += 1;
            console.warn(`Failed to apply server bookmark: ${serverBm.url}`, err);
          }
        }
      } finally {
        isApplyingRemoteChanges = false;
      }

      const finalLocalBookmarks = await getLocalBookmarks();
      await setStorage({
        lastSyncTime: response.serverTime,
        lastLocalBookmarkHashes: finalLocalBookmarks.map((bookmark) => bookmark.bookmarkHash),
      });

      const { localDuplicateCount } = detectLocalDuplicates(finalLocalBookmarks);

      return {
        success: true,
        created: response.results.created,
        updated: response.results.updated,
        duplicatesCollapsed: Number(response.results.duplicatesCollapsed || 0),
        localDuplicateCount,
        pulled,
        remoteUpdated,
        removed,
        applyErrors,
        serverBookmarks: safeBookmarkArray(response).length,
        skippedInvalidUrls,
        skippedInvalidBookmarkUrls,
      };
    }

    for (let i = 0; i < totalBatches; i++) {
      const bookmarkChunk = bookmarkChunks[i] || [];
      const deletedChunk = deletedChunks[i] || [];
      const isFirstBatch = i === 0;
      const response = await apiRequest('/bookmarks/sync', {
        method: 'POST',
        body: JSON.stringify({
          bookmarks: bookmarkChunk,
          deletedBookmarkHashes: deletedChunk,
          lastSyncTime: isFirstBatch ? (lastSyncTime || null) : null,
          browserName: browserName || 'Unknown',
          syncMode: 'push-only',
        }),
      });

      pushCreated += Number(response?.results?.created || 0);
      pushUpdated += Number(response?.results?.updated || 0);
      pushDeleted += Number(response?.results?.deleted || 0);
      lastServerTime = response?.serverTime || lastServerTime;
    }

    const response = await apiRequest('/bookmarks', { method: 'GET' });

    const lookup = buildLocalBookmarkLookup(localBookmarks);
    const usedLocalIds = new Set();
    let pulled = 0;
    let remoteUpdated = 0;
    let removed = 0;
    let applyErrors = 0;

    isApplyingRemoteChanges = true;
    try {
      for (const serverBm of safeBookmarkArray(response)) {
        try {
          if (!isSyncableHttpUrl(serverBm.url)) {
            applyErrors += 1;
            continue;
          }
          const localBookmark = resolveLocalBookmarkForServer(serverBm, lookup, usedLocalIds);
          if (localBookmark?.localId) {
            usedLocalIds.add(localBookmark.localId);
          }
          const result = await applyServerBookmark(localBookmark, serverBm);
          pulled += result.created;
          remoteUpdated += result.updated;
          removed += result.deleted;
        } catch (err) {
          applyErrors += 1;
          console.warn(`Failed to apply server bookmark: ${serverBm.url}`, err);
        }
      }
    } finally {
      isApplyingRemoteChanges = false;
    }

    const finalLocalBookmarks = await getLocalBookmarks();
    await setStorage({
      lastSyncTime: response.serverTime || lastServerTime,
      lastLocalBookmarkHashes: finalLocalBookmarks.map((bookmark) => bookmark.bookmarkHash),
    });

    const { localDuplicateCount } = detectLocalDuplicates(finalLocalBookmarks);

    return {
      success: true,
      created: pushCreated,
      updated: pushUpdated,
      duplicatesCollapsed: 0,
      localDuplicateCount,
      pulled,
      remoteUpdated,
      removed,
      applyErrors,
      serverBookmarks: safeBookmarkArray(response).length,
      deleted: pushDeleted,
      chunksProcessed: totalBatches,
      skippedInvalidUrls,
      skippedInvalidBookmarkUrls,
    };
  } finally {
    isSyncInProgress = false;
  }
}

/**
 * Push-only: send local bookmarks to server
 */
async function pushBookmarks() {
  const urlValid = await verifyServerUrlBinding();
  if (!urlValid) {
    throw new Error('Server URL has changed since login. Please log out and log in again.');
  }

  const { user, browserName, lastLocalBookmarkHashes } = await getStorage([
    'user',
    'browserName',
    'lastLocalBookmarkHashes',
  ]);

  if (!user) throw new Error('Not authenticated');

  const { bookmarks: localBookmarks, skippedInvalidUrls, skippedInvalidBookmarkUrls } = await getLocalBookmarksWithStats();
  const deletedBookmarkHashes = getDeletedHashes(lastLocalBookmarkHashes, localBookmarks);

  const bookmarkChunks = chunkArray(localBookmarks, MAX_BOOKMARKS_PER_SYNC_CHUNK);
  const deletedChunks = chunkArray(deletedBookmarkHashes, MAX_BOOKMARKS_PER_SYNC_CHUNK);
  const totalBatches = Math.max(bookmarkChunks.length || 0, deletedChunks.length || 0, 1);
  let lastServerTime = new Date().toISOString();

  for (let i = 0; i < totalBatches; i++) {
    const bookmarkChunk = bookmarkChunks[i] || [];
    const deletedChunk = deletedChunks[i] || [];
    const response = await apiRequest('/bookmarks/sync', {
      method: 'POST',
      body: JSON.stringify({
        bookmarks: bookmarkChunk,
        deletedBookmarkHashes: deletedChunk,
        browserName: browserName || 'Unknown',
        lastSyncTime: null,
        syncMode: 'push-only',
      }),
    });
    lastServerTime = response?.serverTime || lastServerTime;
  }

  await setStorage({
    lastSyncTime: lastServerTime,
    lastLocalBookmarkHashes: localBookmarks.map((bookmark) => bookmark.bookmarkHash),
  });

  return {
    success: true,
    count: localBookmarks.length,
    skippedInvalidUrls,
    skippedInvalidBookmarkUrls,
  };
}

/**
 * Pull-only: fetch bookmarks from server and add missing ones locally
 */
async function pullBookmarks() {
  const urlValid = await verifyServerUrlBinding();
  if (!urlValid) {
    throw new Error('Server URL has changed since login. Please log out and log in again.');
  }

  const { user } = await getStorage(['user']);
  if (!user) throw new Error('Not authenticated');

  const response = await apiRequest('/bookmarks');
  const localBookmarks = await getLocalBookmarks();
  const lookup = buildLocalBookmarkLookup(localBookmarks);
  const usedLocalIds = new Set();

  let added = 0;
  let updated = 0;
  let deleted = 0;
  let applyErrors = 0;

  isApplyingRemoteChanges = true;
  try {
    for (const serverBm of safeBookmarkArray(response)) {
      try {
        if (!isSyncableHttpUrl(serverBm.url)) {
          applyErrors += 1;
          continue;
        }
        const localBookmark = resolveLocalBookmarkForServer(serverBm, lookup, usedLocalIds);
        if (localBookmark?.localId) {
          usedLocalIds.add(localBookmark.localId);
        }
        const result = await applyServerBookmark(localBookmark, serverBm);
        added += result.created;
        updated += result.updated;
        deleted += result.deleted;
      } catch (err) {
        applyErrors += 1;
        console.warn(`Failed to apply server bookmark: ${serverBm.url}`, err);
      }
    }
  } finally {
    isApplyingRemoteChanges = false;
  }

  const finalLocalBookmarks = await getLocalBookmarks();
  await setStorage({
    lastSyncTime: response.serverTime,
    lastLocalBookmarkHashes: finalLocalBookmarks.map((bookmark) => bookmark.bookmarkHash),
  });

  return {
    success: true,
    count: added,
    updated,
    deleted,
    applyErrors,
    serverBookmarks: safeBookmarkArray(response).length,
  };
}
