/**
 * LinkNest - Background Service Worker Core Module
 * Shared constants and helper utilities
 */

// ===== Constants =====
const DEFAULT_SYNC_INTERVAL = 15; // minutes
const MAX_BOOKMARKS_PER_SYNC_CHUNK = 10000;

// Cross-browser API: Firefox MV2 'browser.*' returns Promises;
// Chrome MV3 'chrome.*' returns Promises. Firefox's 'chrome.*' does NOT.
const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;

const linkNestClient = self.LinkNestClient;

if (!linkNestClient) {
  throw new Error('Shared LinkNest client helpers failed to load.');
}

// ===== Cross-Browser Root Folder Normalization =====
// Different browsers use different names for root bookmark folders.
// We normalize them to canonical names so the same bookmark gets the same
// hash (and folderPath) regardless of which browser pushes it.

const ROOT_FOLDER_ALIASES = {
  'bookmarks bar': 'Toolbar',
  'bookmarks toolbar': 'Toolbar',
  'toolbar bookmarks': 'Toolbar',
  'favourites bar': 'Toolbar',
  'other bookmarks': 'Other',
  'other favourites': 'Other',
  'mobile bookmarks': 'Mobile',
  'bookmarks menu': 'Other',   // Firefox Menu → Other (Chrome has no Menu root)
};

const CANONICAL_ROOTS = new Set(['Toolbar', 'Other', 'Mobile']);

/**
 * Map a browser-specific root folder name to its canonical form.
 * Returns null if the name is not a known root folder.
 */
function normalizeRootFolderName(name) {
  if (!name) return null;
  return ROOT_FOLDER_ALIASES[name.toLowerCase().trim()] || null;
}

// ===== Storage Helpers =====

async function getStorage(keys) {
  return linkNestClient.getStorage(keys);
}

async function setStorage(data) {
  return linkNestClient.setStorage(data);
}

// ===== API Helpers =====

async function apiRequest(endpoint, options = {}, allowRefresh = true) {
  return linkNestClient.apiRequest(endpoint, options, { allowRefresh });
}

// ===== Bookmark Tree Helpers =====

/**
 * Flatten bookmark tree into an array of bookmark objects
 * Preserves folder structure as folderPath with normalized root names
 */
function flattenBookmarks(nodes, path = '', stats = { skippedInvalidUrls: 0, skippedInvalidBookmarkUrls: [] }) {
  const bookmarks = [];

  for (const node of nodes) {
    if (node.url) {
      if (isSyncableHttpUrl(node.url)) {
        // It's a bookmark
        bookmarks.push({
          bookmarkHash: generateHash(node.url.trim() + '|' + (path || 'root')),
          title: node.title || '',
          url: node.url.trim(),
          folderPath: path,
          index: node.index || 0,
          localId: node.id,
        });
      } else {
        stats.skippedInvalidUrls += 1;
        stats.skippedInvalidBookmarkUrls.push({
          title: node.title || '',
          url: typeof node.url === 'string' ? node.url.trim() : '',
          folderPath: path || 'root',
          reason: 'non-http-https-url',
        });
      }
    }

    if (node.children) {
      // It's a folder — normalize root-level browser folder names to canonical
      // names so the same bookmark gets the same hash across Chrome and Firefox.
      let folderName = node.title;
      if (!path) {
        const canonical = normalizeRootFolderName(folderName);
        if (canonical) folderName = canonical;
      }
      const folderPath = path ? `${path}/${folderName}` : folderName;
      bookmarks.push(...flattenBookmarks(node.children, folderPath, stats));
    }
  }

  return bookmarks;
}

function isSyncableHttpUrl(value) {
  if (typeof value !== 'string') return false;
  const trimmed = value.trim();
  if (!trimmed) return false;

  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * Simple hash function to create a bookmark identifier
 * Based on URL + folder path for uniqueness
 */
function generateHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32-bit integer
  }
  return 'bm_' + Math.abs(hash).toString(36);
}

/**
 * Get all local bookmarks as a flat array
 */
async function getLocalBookmarks() {
  const { bookmarks } = await getLocalBookmarksWithStats();
  return bookmarks;
}

async function getLocalBookmarksWithStats() {
  const tree = await api.bookmarks.getTree();
  const stats = { skippedInvalidUrls: 0, skippedInvalidBookmarkUrls: [] };
  const bookmarks = flattenBookmarks(tree, '', stats);
  return {
    bookmarks,
    skippedInvalidUrls: stats.skippedInvalidUrls,
    skippedInvalidBookmarkUrls: stats.skippedInvalidBookmarkUrls,
  };
}

function isOrganizeExcludedFolderName(name) {
  return typeof name === 'string' && name.trim().startsWith('-');
}

function isOrganizeExcludedFolderPath(folderPath = '') {
  if (typeof folderPath !== 'string' || !folderPath) return false;
  return folderPath
    .split('/')
    .filter(Boolean)
    .some((segment) => isOrganizeExcludedFolderName(segment));
}

function buildBookmarkMap(bookmarks) {
  const map = new Map();
  for (const bookmark of bookmarks) {
    map.set(bookmark.bookmarkHash, bookmark);
  }
  return map;
}

function getDeletedHashes(previousHashes = [], currentBookmarks = []) {
  if (!Array.isArray(previousHashes) || previousHashes.length === 0) {
    return [];
  }

  const currentHashes = new Set(currentBookmarks.map((bookmark) => bookmark.bookmarkHash));
  return previousHashes.filter((bookmarkHash) => !currentHashes.has(bookmarkHash));
}

function chunkArray(items = [], chunkSize) {
  if (!Array.isArray(items) || items.length === 0) return [];
  const size = Number.isInteger(chunkSize) && chunkSize > 0 ? chunkSize : items.length;
  const chunks = [];
  for (let i = 0; i < items.length; i += size) {
    chunks.push(items.slice(i, i + size));
  }
  return chunks;
}

async function applyServerBookmark(localBookmark, serverBookmark) {
  if (serverBookmark.isDeleted) {
    if (localBookmark) {
      await api.bookmarks.remove(localBookmark.localId);
      return { created: 0, updated: 0, deleted: 1 };
    }

    return { created: 0, updated: 0, deleted: 0 };
  }

  if (!localBookmark) {
    const parentId = await ensureFolderPath(serverBookmark.folderPath);
    const createPayload = {
      parentId,
      title: serverBookmark.title,
      url: serverBookmark.url,
    };
    const hasValidIndex = Number.isInteger(serverBookmark.index) && serverBookmark.index >= 0;
    if (hasValidIndex) {
      createPayload.index = serverBookmark.index;
    }

    try {
      await api.bookmarks.create(createPayload);
    } catch (createError) {
      if (!hasValidIndex) {
        throw createError;
      }

      // Index values from another browser/folder snapshot can be out-of-range
      // on this browser. Retry append-create without index for resilience.
      await api.bookmarks.create({
        parentId,
        title: serverBookmark.title,
        url: serverBookmark.url,
      });
    }
    return { created: 1, updated: 0, deleted: 0 };
  }

  const titleChanged = localBookmark.title !== serverBookmark.title;
  const urlChanged = localBookmark.url !== serverBookmark.url;
  const folderChanged = (localBookmark.folderPath || '') !== (serverBookmark.folderPath || '');

  if (titleChanged || urlChanged) {
    await api.bookmarks.update(localBookmark.localId, {
      title: serverBookmark.title,
      url: serverBookmark.url,
    });
  }

  // Only move if the folder actually changed. Index is intentionally excluded
  // because different browsers have different item counts in folders, causing
  // perpetual index ping-pong between browsers.
  if (folderChanged) {
    const parentId = await ensureFolderPath(serverBookmark.folderPath);
    await api.bookmarks.move(localBookmark.localId, { parentId });
  }

  return {
    created: 0,
    updated: titleChanged || urlChanged || folderChanged ? 1 : 0,
    deleted: 0,
  };
}

/**
 * Find or create a folder path in the bookmark tree.
 * Handles canonical root names (Toolbar, Other, Mobile, Menu) and
 * legacy browser-specific names (Bookmarks Bar, Bookmarks Toolbar, etc.)
 * by mapping them to the browser's actual root bookmark folder.
 */
async function ensureFolderPath(folderPath) {
  const tree = await api.bookmarks.getTree();
  const rootChildren = tree[0].children;

  if (!folderPath) {
    // Default to "Other Bookmarks"
    const otherBookmarks = rootChildren.find(
      (c) => normalizeRootFolderName(c.title) === 'Other'
    );
    return otherBookmarks?.id || rootChildren[1]?.id || '2';
  }

  const parts = folderPath.split('/').filter(Boolean);
  // Default parent is the toolbar / bookmarks bar
  const defaultToolbar = rootChildren.find(
    (c) => normalizeRootFolderName(c.title) === 'Toolbar'
  );
  let parentId = defaultToolbar?.id || rootChildren[0]?.id || '1';

  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];

    // For the first path component, map canonical or browser-specific root
    // names to the browser's actual root folder
    if (i === 0) {
      let canonical = CANONICAL_ROOTS.has(part) ? part : normalizeRootFolderName(part);
      // Legacy: old server data may have 'Menu' paths from before the
      // normalization change. Map to 'Other' so those bookmarks land
      // in the correct root folder on browsers without a Menu root.
      if (part === 'Menu') canonical = 'Other';
      if (canonical) {
        const rootFolder = rootChildren.find(
          (c) => normalizeRootFolderName(c.title) === canonical
        );
        if (rootFolder) {
          parentId = rootFolder.id;
          continue;
        }
      }
    }

    // Search for existing subfolder
    const children = await api.bookmarks.getChildren(parentId);
    const existing = children.find((c) => c.title === part && !c.url);

    if (existing) {
      parentId = existing.id;
    } else {
      // Create the folder
      const newFolder = await api.bookmarks.create({
        parentId,
        title: part,
      });
      parentId = newFolder.id;
    }
  }

  return parentId;
}

// ===== Local Duplicate Detection =====

const CLIENT_TRACKING_PARAMS = new Set([
  'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content',
  'utm_id', 'utm_source_platform', 'utm_creative_format', 'utm_marketing_tactic',
  'fbclid', 'gclid', 'gclsrc', 'dclid', 'gbraid', 'wbraid',
  'msclkid', 'twclid', 'igshid', 'mc_cid', 'mc_eid',
  'ref', 'source', '_ga', '_gl',
]);

function normalizeUrlForDedup(url) {
  try {
    const u = new URL(url);
    for (const param of CLIENT_TRACKING_PARAMS) {
      u.searchParams.delete(param);
    }
    if (u.pathname.length > 1 && u.pathname.endsWith('/')) {
      u.pathname = u.pathname.slice(0, -1);
    }
    return u.toString().toLowerCase();
  } catch {
    return String(url || '').toLowerCase();
  }
}

/**
 * Detect local bookmarks that share the same normalized URL across different folders.
 * Returns { localDuplicateCount, localDuplicateGroups } where groups is an array of
 * { url, bookmarks: [{ bookmarkHash, title, folderPath, localId }] } with 2+ entries.
 */
function detectLocalDuplicates(bookmarks) {
  const byNormalizedUrl = new Map();
  for (const bm of bookmarks) {
    const key = normalizeUrlForDedup(bm.url);
    if (!byNormalizedUrl.has(key)) {
      byNormalizedUrl.set(key, []);
    }
    byNormalizedUrl.get(key).push(bm);
  }

  const groups = [];
  for (const [, entries] of byNormalizedUrl) {
    if (entries.length < 2) continue;
    groups.push({
      url: entries[0].url,
      bookmarks: entries.map((bm) => ({
        bookmarkHash: bm.bookmarkHash,
        title: bm.title,
        url: bm.url,
        folderPath: bm.folderPath,
        localId: bm.localId,
      })),
    });
  }

  const totalExtras = groups.reduce((sum, g) => sum + (g.bookmarks.length - 1), 0);
  return { localDuplicateCount: totalExtras, localDuplicateGroups: groups };
}

// ===== Server URL Binding =====

async function verifyServerUrlBinding() {
  return linkNestClient.verifyServerUrlBinding();
}
