// ===== AI Bookmark Organization =====

/**
 * Get local bookmarks and send to server for AI categorization
 */
async function categorizeLocalBookmarks() {
  // Verify server URL binding
  const urlValid = await verifyServerUrlBinding();
  if (!urlValid) {
    throw new Error('Server URL has changed since login. Please log out and log in again.');
  }

  const localBookmarks = await getLocalBookmarks();
  const organizeExcludedCount = localBookmarks.filter((bm) => isOrganizeExcludedFolderPath(bm.folderPath)).length;
  const organizableBookmarks = localBookmarks.filter((bm) => !isOrganizeExcludedFolderPath(bm.folderPath));

  if (organizableBookmarks.length === 0) {
    return {
      success: true,
      categories: {},
      stats: { total: 0, categorized: 0, byDomain: 0, byAI: 0, uncategorized: 0, organizeExcluded: organizeExcludedCount },
    };
  }

  // Send url, title, bookmarkHash, and folderPath to server.
  // folderPath is used server-side as a hint to improve AI categorization
  // accuracy and is never stored — only the resolved category label is persisted.
  const payload = organizableBookmarks.map((bm) => ({
    url: bm.url,
    title: bm.title,
    bookmarkHash: bm.bookmarkHash,
    folderPath: bm.folderPath || '',
  }));

  const result = await apiRequest('/bookmarks/categorize', {
    method: 'POST',
    body: JSON.stringify({ bookmarks: payload }),
  });

  return {
    success: true,
    categories: result.categories,
    stats: {
      ...result.stats,
      organizeExcluded: organizeExcludedCount,
    },
  };
}

async function removeEmptyFoldersAfterOrganize() {
  const tree = await api.bookmarks.getTree();
  const rootChildren = tree?.[0]?.children || [];
  let removedEmptyFolders = 0;

  const pruneDescendants = async (folderId) => {
    const children = await api.bookmarks.getChildren(folderId);
    let hasAnyContent = false;

    for (const child of children) {
      if (child.url) {
        hasAnyContent = true;
        continue;
      }

      const childHasContent = await pruneDescendants(child.id);
      if (!childHasContent && !isOrganizeExcludedFolderName(child.title)) {
        try {
          await api.bookmarks.removeTree(child.id);
          removedEmptyFolders += 1;
        } catch (err) {
          console.warn(`Failed to remove empty folder "${child.title}":`, err.message);
          hasAnyContent = true;
        }
      } else {
        hasAnyContent = true;
      }
    }

    return hasAnyContent;
  };

  for (const root of rootChildren) {
    if (!root.url) {
      await pruneDescendants(root.id);
    }
  }

  return removedEmptyFolders;
}

/**
 * Apply AI categorization — move bookmarks into category folders
 * @param {Object} categories - { "Shopping": [{bookmarkHash, url, title}, ...], ... }
 */
async function applyOrganize(categories) {
  if (!categories || typeof categories !== 'object') {
    throw new Error('Invalid categories data');
  }

  const localBookmarks = await getLocalBookmarks();
  // Build lookup: bookmarkHash → bookmark
  const hashToLocal = new Map();
  for (const bm of localBookmarks) {
    hashToLocal.set(bm.bookmarkHash, bm);
  }

  // Build URL lookup as fallback (supports duplicate local URLs)
  const urlToLocals = new Map();
  for (const bm of localBookmarks) {
    if (!urlToLocals.has(bm.url)) {
      urlToLocals.set(bm.url, []);
    }
    urlToLocals.get(bm.url).push(bm);
  }

  let moved = 0;
  let foldersCreated = 0;
  const createdFolders = new Set();
  const processedLocalIds = new Set();

  isApplyingRemoteChanges = true;

  try {
    for (const [category, bookmarks] of Object.entries(categories)) {
      if (!Array.isArray(bookmarks) || bookmarks.length === 0) continue;

      // Determine folder path — place under Toolbar/{Category}
      const folderPath = `Toolbar/${category}`;

      // Create the category folder (ensureFolderPath handles deduplication)
      const parentId = await ensureFolderPath(folderPath);
      if (!createdFolders.has(category)) {
        createdFolders.add(category);
        foldersCreated++;
      }

      for (const bm of bookmarks) {
        // Find target locals by hash, then include all same-URL local duplicates.
        const candidates = [];
        const byHash = hashToLocal.get(bm.bookmarkHash);
        if (byHash?.localId) {
          candidates.push(byHash);
        }
        if (bm.url && urlToLocals.has(bm.url)) {
          candidates.push(...urlToLocals.get(bm.url));
        }

        const uniqueCandidates = [];
        const seenLocalIds = new Set();
        for (const candidate of candidates) {
          if (!candidate?.localId) continue;
          if (seenLocalIds.has(candidate.localId)) continue;
          seenLocalIds.add(candidate.localId);
          uniqueCandidates.push(candidate);
        }

        for (const local of uniqueCandidates) {
          if (!local?.localId) continue;
          if (processedLocalIds.has(local.localId)) continue;
          processedLocalIds.add(local.localId);

          // Skip excluded folders and already-correctly-located bookmarks
          if (isOrganizeExcludedFolderPath(local.folderPath)) continue;
          if ((local.folderPath || '') === folderPath) continue;

          try {
            await api.bookmarks.move(local.localId, { parentId });
            moved++;
          } catch (err) {
            console.warn(`Failed to move bookmark "${bm.title || bm.url}":`, err.message);
          }
        }
      }
    }
  } finally {
    isApplyingRemoteChanges = false;
  }

  const removedEmptyFolders = await removeEmptyFoldersAfterOrganize();

  return {
    success: true,
    moved,
    foldersCreated,
    removedEmptyFolders,
  };
}

// ===== Duplicate Detection & Removal =====

async function handleDetectDuplicates() {
  const localBookmarks = await getLocalBookmarks();
  const { localDuplicateCount, localDuplicateGroups } = detectLocalDuplicates(localBookmarks);
  return {
    success: true,
    count: localDuplicateCount,
    groups: localDuplicateGroups,
  };
}

async function handleRemoveDuplicates(localIds = []) {
  if (!Array.isArray(localIds) || localIds.length === 0) {
    return { success: true, removed: 0, failed: 0 };
  }

  let removed = 0;
  let failed = 0;

  for (const id of localIds) {
    try {
      await api.bookmarks.remove(id);
      removed += 1;
    } catch (err) {
      console.warn(`Failed to remove duplicate bookmark ${id}:`, err);
      failed += 1;
    }
  }

  return { success: true, removed, failed };
}

// ===== Message Handling =====

async function handleMessage(message) {
  try {
    switch (message.action) {
      case 'sync':
        return await performSync();

      case 'push':
        return await pushBookmarks();

      case 'pull':
        return await pullBookmarks();

      case 'categorize':
        return await categorizeLocalBookmarks();

      case 'applyOrganize':
        return await applyOrganize(message.categories);

      case 'detectDuplicates':
        return await handleDetectDuplicates();

      case 'removeDuplicates':
        return await handleRemoveDuplicates(message.localIds);

      case 'updateSettings':
        await setupAlarm(message.settings);
        return { success: true };

      default:
        return { error: 'Unknown action' };
    }
  } catch (err) {
    console.error(`LinkNest background [${message.action}] error:`, err);
    return { success: false, error: err.message || String(err) || 'Unknown background error' };
  }
}

// Firefox MV2: browser.runtime.onMessage listener must RETURN a Promise.
// Chrome MV3: api.runtime.onMessage uses sendResponse + return true.
if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.onMessage) {
  // Firefox: use browser API — listener returns a Promise directly
  browser.runtime.onMessage.addListener((message) => {
    return handleMessage(message);
  });
} else {
  // Chrome: use chrome API — listener uses sendResponse callback
  api.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message).then(sendResponse);
    return true; // keep channel open for async sendResponse
  });
}
