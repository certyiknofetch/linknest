/**
 * LinkNest - Background Service Worker Loader
 * Keeps manifest entrypoint stable while loading modular background scripts.
 */

importScripts(
  '../shared/client.js',
  './modules/core.js',
  './modules/sync-engine.js',
  './modules/organize-and-messages.js',
  './modules/runtime-listeners.js'
);
