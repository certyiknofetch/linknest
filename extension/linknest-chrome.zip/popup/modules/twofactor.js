// ===== 2FA Setup =====

const securitySection = document.getElementById('securitySection');
const twoFactorBadge = document.getElementById('twoFactorBadge');
const twoFactorEnableSection = document.getElementById('twoFactorEnableSection');
const twoFactorDisableSection = document.getElementById('twoFactorDisableSection');
const twoFactorSetupFlow = document.getElementById('twoFactorSetupFlow');
const backupCodesSection = document.getElementById('backupCodesSection');
const backupCodesList = document.getElementById('backupCodesList');
const backupCodesRemaining = document.getElementById('backupCodesRemaining');
const totpSecret = document.getElementById('totpSecret');
const totpQrImage = document.getElementById('totpQrImage');
const secretKeyBox = document.getElementById('secretKeyBox');
const toggleSecretBtn = document.getElementById('toggleSecretBtn');
const totpVerifyCode = document.getElementById('totpVerifyCode');
const setup2faBtn = document.getElementById('setup2faBtn');
const verify2faBtn = document.getElementById('verify2faBtn');
const disable2faBtn = document.getElementById('disable2faBtn');
const copySecretBtn = document.getElementById('copySecretBtn');
const dismissBackupCodesBtn = document.getElementById('dismissBackupCodesBtn');
const setup2faError = document.getElementById('setup2faError');
const disable2faVerify = document.getElementById('disable2faVerify');
const disable2faInput = document.getElementById('disable2faInput');
const disable2faConfirmBtn = document.getElementById('disable2faConfirmBtn');
const disable2faCancelBtn = document.getElementById('disable2faCancelBtn');
const disable2faError = document.getElementById('disable2faError');

/**
 * Load 2FA status from server and update the Security section in Settings.
 * Only shows the section when the user is logged in.
 */
async function refresh2faStatus() {
  const { user } = await getStorage(['user']);
  if (!user) {
    securitySection.classList.add('hidden');
    return;
  }

  try {
    const data = await apiRequest('/auth/2fa/status');
    const info = data.twoFactor;

    securitySection.classList.remove('hidden');

    // Reset sub-sections
    twoFactorSetupFlow.classList.add('hidden');
    backupCodesSection.classList.add('hidden');
    setup2faError.classList.add('hidden');
    totpVerifyCode.value = '';

    if (info.enabled) {
      twoFactorBadge.textContent = 'On';
      twoFactorBadge.className = 'badge badge-on';
      twoFactorEnableSection.classList.add('hidden');
      twoFactorDisableSection.classList.remove('hidden');
      backupCodesRemaining.textContent = info.backupCodesCount ?? 0;
    } else {
      twoFactorBadge.textContent = 'Off';
      twoFactorBadge.className = 'badge badge-off';
      twoFactorEnableSection.classList.remove('hidden');
      twoFactorDisableSection.classList.add('hidden');
    }
  } catch {
    // Not logged in or network error — hide section
    securitySection.classList.add('hidden');
  }
}

// Start 2FA setup: request secret + QR from server
function createEyeToggleIcon(isHidden) {
  const svgNs = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNs, 'svg');
  svg.setAttribute('width', '14');
  svg.setAttribute('height', '14');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '2');

  if (isHidden) {
    const path1 = document.createElementNS(svgNs, 'path');
    path1.setAttribute('d', 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z');
    const circle = document.createElementNS(svgNs, 'circle');
    circle.setAttribute('cx', '12');
    circle.setAttribute('cy', '12');
    circle.setAttribute('r', '3');
    svg.appendChild(path1);
    svg.appendChild(circle);
  } else {
    const path1 = document.createElementNS(svgNs, 'path');
    path1.setAttribute('d', 'M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24');
    const line = document.createElementNS(svgNs, 'line');
    line.setAttribute('x1', '1');
    line.setAttribute('y1', '1');
    line.setAttribute('x2', '23');
    line.setAttribute('y2', '23');
    svg.appendChild(path1);
    svg.appendChild(line);
  }

  return svg;
}

function setSecretToggleButton(buttonEl, isHidden) {
  const label = document.createTextNode(isHidden ? ' Show secret key' : ' Hide secret key');
  buttonEl.replaceChildren(createEyeToggleIcon(isHidden), label);
}

setup2faBtn.addEventListener('click', async () => {
  setup2faBtn.disabled = true;
  setup2faError.classList.add('hidden');

  try {
    const data = await apiRequest('/auth/2fa/totp/setup/start', { method: 'POST' });

    // Show QR code
    if (data.qrDataUrl) {
      totpQrImage.src = data.qrDataUrl;
      totpQrImage.classList.remove('hidden');
    } else {
      totpQrImage.classList.add('hidden');
    }

    // Set secret (hidden by default)
    totpSecret.textContent = data.secret;
    secretKeyBox.classList.add('hidden');
    setSecretToggleButton(toggleSecretBtn, true);

    twoFactorSetupFlow.classList.remove('hidden');
    twoFactorEnableSection.classList.add('hidden');
    totpVerifyCode.focus();
  } catch (err) {
    showError(setup2faError, err.message);
  } finally {
    setup2faBtn.disabled = false;
  }
});

// Toggle secret key visibility
toggleSecretBtn.addEventListener('click', () => {
  const isHidden = secretKeyBox.classList.contains('hidden');
  if (isHidden) {
    secretKeyBox.classList.remove('hidden');
    setSecretToggleButton(toggleSecretBtn, false);
  } else {
    secretKeyBox.classList.add('hidden');
    setSecretToggleButton(toggleSecretBtn, true);
  }
});

// Copy secret to clipboard
copySecretBtn.addEventListener('click', async () => {
  const secret = totpSecret.textContent;
  if (!secret || secret === '—') return;

  try {
    await navigator.clipboard.writeText(secret);
    copySecretBtn.title = 'Copied!';
    setTimeout(() => { copySecretBtn.title = 'Copy secret'; }, 2000);
  } catch {
    // Fallback: select the text
    const range = document.createRange();
    range.selectNodeContents(totpSecret);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }
});

// Verify TOTP code and enable 2FA
verify2faBtn.addEventListener('click', async () => {
  const code = totpVerifyCode.value.trim();
  if (!code) {
    showError(setup2faError, 'Enter the 6-digit code from your authenticator.');
    return;
  }

  verify2faBtn.disabled = true;
  setup2faError.classList.add('hidden');

  try {
    const data = await apiRequest('/auth/2fa/totp/setup/verify', {
      method: 'POST',
      body: JSON.stringify({ code }),
    });

    // Show backup codes
    twoFactorSetupFlow.classList.add('hidden');
    backupCodesSection.classList.remove('hidden');
    backupCodesList.innerHTML = '';
    for (const bc of data.backupCodes) {
      const span = document.createElement('span');
      span.textContent = bc;
      backupCodesList.appendChild(span);
    }

    // Update badge
    twoFactorBadge.textContent = 'On';
    twoFactorBadge.className = 'badge badge-on';
  } catch (err) {
    showError(setup2faError, err.message);
  } finally {
    verify2faBtn.disabled = false;
  }
});

// Dismiss backup codes after user confirms they saved them
dismissBackupCodesBtn.addEventListener('click', async () => {
  backupCodesSection.classList.add('hidden');
  // 2FA is now active — after enabling, all refresh tokens are revoked
  // so the user needs to re-login. Force re-login.
  await removeStorage(['token', 'refreshToken', 'user', 'lastSyncTime', 'lastLocalBookmarkHashes']);
  resetTwoFactorState();
  showView(loginView);
  authForm.reset();
  hideError(authError);
  addLogEntry('2FA enabled — please log in again', 'success');
});

// Disable 2FA — show verification inline first
disable2faBtn.addEventListener('click', () => {
  disable2faBtn.classList.add('hidden');
  disable2faVerify.classList.remove('hidden');
  disable2faInput.value = '';
  hideError(disable2faError);
  disable2faInput.focus();
});

disable2faCancelBtn.addEventListener('click', () => {
  disable2faVerify.classList.add('hidden');
  disable2faBtn.classList.remove('hidden');
  disable2faInput.value = '';
  hideError(disable2faError);
});

disable2faConfirmBtn.addEventListener('click', async () => {
  const code = disable2faInput.value.trim();
  if (!code) {
    showError(disable2faError, 'Enter your authenticator code to continue.');
    return;
  }

  disable2faConfirmBtn.disabled = true;
  hideError(disable2faError);

  try {
    await apiRequest('/auth/2fa/disable', {
      method: 'POST',
      body: JSON.stringify({ totpCode: code }),
    });

    // 2FA disabled — all refresh tokens revoked, force re-login
    await removeStorage(['token', 'refreshToken', 'user', 'lastSyncTime', 'lastLocalBookmarkHashes']);
    resetTwoFactorState();
    showView(loginView);
    authForm.reset();
    hideError(authError);
    addLogEntry('2FA disabled — please log in again', 'success');
  } catch (err) {
    showError(disable2faError, err.message);
  } finally {
    disable2faConfirmBtn.disabled = false;
  }
});

