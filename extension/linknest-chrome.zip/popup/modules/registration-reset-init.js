// ===== Registration TOTP Setup =====

regToggleSecretBtn.addEventListener('click', () => {
  const isHidden = regSecretKeyBox.classList.contains('hidden');
  if (isHidden) {
    regSecretKeyBox.classList.remove('hidden');
    setSecretToggleButton(regToggleSecretBtn, false);
  } else {
    regSecretKeyBox.classList.add('hidden');
    setSecretToggleButton(regToggleSecretBtn, true);
  }
});

regCopySecretBtn.addEventListener('click', async () => {
  const secret = regTotpSecret.textContent;
  if (!secret || secret === '—') return;
  try {
    await navigator.clipboard.writeText(secret);
    regCopySecretBtn.title = 'Copied!';
    setTimeout(() => { regCopySecretBtn.title = 'Copy secret'; }, 2000);
  } catch {
    const range = document.createRange();
    range.selectNodeContents(regTotpSecret);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }
});

regVerify2faBtn.addEventListener('click', async () => {
  const code = regTotpVerifyCode.value.trim();
  if (!code) {
    regSetupError.textContent = 'Enter the 6-digit code from your authenticator.';
    regSetupError.classList.remove('hidden');
    return;
  }

  regVerify2faBtn.disabled = true;
  regSetupError.classList.add('hidden');

  try {
    const data = await apiRequest('/auth/register/verify-totp', {
      method: 'POST',
      body: JSON.stringify({
        setupToken: pendingRegistrationSetupToken,
        code,
      }),
    });

    // Save auth data + bind server URL to this session
    pendingRegistrationUser = data.user;
    const regServerUrl = await getServerUrl();
    const regBoundHash = await hashString(regServerUrl);
    await setStorage({
      user: data.user,
      boundServerUrlHash: regBoundHash,
    });
    await removeStorage(['token', 'refreshToken']);

    // Show backup codes
    regTotpSetup.classList.add('hidden');
    regBackupCodes.classList.remove('hidden');
    regBackupCodesList.innerHTML = '';
    for (const bc of data.backupCodes) {
      const span = document.createElement('span');
      span.textContent = bc;
      regBackupCodesList.appendChild(span);
    }
  } catch (err) {
    regSetupError.textContent = err.message;
    regSetupError.classList.remove('hidden');
  } finally {
    regVerify2faBtn.disabled = false;
  }
});

regDismissBackupBtn.addEventListener('click', async () => {
  regBackupCodes.classList.add('hidden');
  resetTwoFactorState();
  if (pendingRegistrationUser) {
    showDashboard(pendingRegistrationUser);
    pendingRegistrationUser = null;
  } else {
    const { user } = await getStorage(['user']);
    if (user) showDashboard(user);
  }
});

// ===== Reset Password Flow =====

forgotPasswordBtn.addEventListener('click', () => {
  authForm.classList.add('hidden');
  authTabs.classList.add('hidden');
  forgotPasswordBtn.classList.add('hidden');
  loginTitle.classList.add('hidden');
  loginSubtitle.classList.add('hidden');
  resetPasswordView.classList.remove('hidden');
  resetStep1.classList.remove('hidden');
  resetStep2.classList.add('hidden');
  hideError(resetStep1Error);
  hideError(resetStep2Error);
  resetEmail.value = document.getElementById('email').value.trim();
  resetTotp.value = '';
  pendingResetToken = null;
  resetEmail.focus();
});

resetCancelBtn.addEventListener('click', () => {
  resetPasswordView.classList.add('hidden');
  authForm.classList.remove('hidden');
  authTabs.classList.remove('hidden');
  forgotPasswordBtn.classList.remove('hidden');
  loginTitle.classList.remove('hidden');
  loginSubtitle.classList.remove('hidden');
  pendingResetToken = null;
  hideError(authError);
});

resetVerifyBtn.addEventListener('click', async () => {
  const email = resetEmail.value.trim();
  const totp = resetTotp.value.trim();
  if (!email || !totp) {
    showError(resetStep1Error, 'Please enter your email and authenticator code.');
    return;
  }
  resetVerifyBtn.disabled = true;
  hideError(resetStep1Error);
  try {
    const serverUrl = await getServerUrl();
    const response = await fetch(`${serverUrl}/api/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, totpCode: totp }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || 'Verification failed.');
    }
    if (data.verified && data.resetToken) {
      pendingResetToken = data.resetToken;
      resetStep1.classList.add('hidden');
      resetStep2.classList.remove('hidden');
      resetNewPassword.value = '';
      resetConfirmPassword.value = '';
      hideError(resetStep2Error);
      resetNewPassword.focus();
    }
  } catch (err) {
    showError(resetStep1Error, err.message);
  } finally {
    resetVerifyBtn.disabled = false;
  }
});

resetSubmitBtn.addEventListener('click', async () => {
  const newPw = resetNewPassword.value;
  const confirmPw = resetConfirmPassword.value;
  if (!newPw) {
    showError(resetStep2Error, 'Please enter a new password.');
    return;
  }
  if (newPw !== confirmPw) {
    showError(resetStep2Error, 'Passwords do not match.');
    return;
  }
  if (!pendingResetToken) {
    showError(resetStep2Error, 'Reset session expired. Please start over.');
    return;
  }
  resetSubmitBtn.disabled = true;
  hideError(resetStep2Error);
  try {
    const serverUrl = await getServerUrl();
    const response = await fetch(`${serverUrl}/api/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        newPassword: newPw,
        confirmPassword: confirmPw,
        resetToken: pendingResetToken,
      }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || 'Password reset failed.');
    }
    // Success — go back to login
    pendingResetToken = null;
    resetPasswordView.classList.add('hidden');
    authForm.classList.remove('hidden');
    authTabs.classList.remove('hidden');
    forgotPasswordBtn.classList.remove('hidden');
    loginTitle.classList.remove('hidden');
    loginSubtitle.classList.remove('hidden');
    showError(authError, '');
    // Show success message in auth error field (green-ish style not available, use text)
    authError.textContent = data.message || 'Password reset successfully. Please log in.';
    authError.classList.remove('hidden');
    authError.style.color = '#22c55e';
    setTimeout(() => { authError.style.color = ''; }, 5000);
  } catch (err) {
    showError(resetStep2Error, err.message);
  } finally {
    resetSubmitBtn.disabled = false;
  }
});

// ===== Init =====

grantPermissionBtn.addEventListener('click', async () => {
  await removeStorage(['needsPermissionGrant']);
  permissionBanner.classList.add('hidden');
  const { user } = await getStorage(['user']);
  if (user) {
    try {
      const data = await apiRequest('/auth/me');
      showDashboard(data.user);
    } catch {
      await removeStorage(['token', 'refreshToken', 'user']);
      resetTwoFactorState();
      showView(loginView);
    }
  } else {
    showView(loginView);
  }
});

(async () => {
  setupPersistentLoginHelper();
  // Clean up legacy needsPermissionGrant flag — no longer used.
  const { user, themeMode: savedThemeMode, needsPermissionGrant } = await getStorage([
    'user',
    'themeMode',
    'needsPermissionGrant',
  ]);
  if (needsPermissionGrant) {
    await removeStorage(['needsPermissionGrant']);
  }
  applyTheme(savedThemeMode || 'light');
  extensionVersionValue.textContent = `V${getExtensionVersion()}`;

  if (user) {
    try {
      const data = await apiRequest('/auth/me');
      showDashboard(data.user);
    } catch {
      await removeStorage(['token', 'refreshToken', 'user']);
      resetTwoFactorState();
      showView(loginView);
    }
  } else {
    resetTwoFactorState();
    showView(loginView);
  }
})();
