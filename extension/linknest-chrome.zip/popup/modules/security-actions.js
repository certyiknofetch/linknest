// ===== Server URL Lock =====

function lockServerUrl() {
  const serverUrlInput = document.getElementById('serverUrl');
  serverUrlInput.disabled = true;
  serverUrlInput.classList.add('input-locked');
  lockIconLocked.classList.remove('hidden');
  lockIconUnlocked.classList.add('hidden');
  serverUrlLockBtn.title = 'Unlock to edit';
  if (serverUrlLockTimeout) {
    clearTimeout(serverUrlLockTimeout);
    serverUrlLockTimeout = null;
  }
}

function unlockServerUrl() {
  const serverUrlInput = document.getElementById('serverUrl');
  serverUrlInput.disabled = false;
  serverUrlInput.classList.remove('input-locked');
  lockIconLocked.classList.add('hidden');
  lockIconUnlocked.classList.remove('hidden');
  serverUrlLockBtn.title = 'Click to lock';
  serverUrlInput.focus();
  // Auto-lock after 30 seconds
  if (serverUrlLockTimeout) clearTimeout(serverUrlLockTimeout);
  serverUrlLockTimeout = setTimeout(lockServerUrl, 30000);
}

serverUrlLockBtn.addEventListener('click', async () => {
  const serverUrlInput = document.getElementById('serverUrl');
  if (serverUrlInput.disabled) {
    // Locked → require TOTP to unlock
    const { user } = await getStorage(['user']);
    if (user) {
      // Show TOTP verification inline
      serverUrlUnlockVerify.classList.remove('hidden');
      hideError(serverUrlUnlockError);
      serverUrlUnlockInput.value = '';
      serverUrlUnlockInput.focus();
    } else {
      // Not logged in — unlock freely
      unlockServerUrl();
    }
  } else {
    lockServerUrl();
  }
});

serverUrlUnlockBtn.addEventListener('click', async () => {
  const code = serverUrlUnlockInput.value.trim();
  if (!code) {
    showError(serverUrlUnlockError, 'Enter your authenticator code.');
    return;
  }
  serverUrlUnlockBtn.disabled = true;
  hideError(serverUrlUnlockError);
  try {
    await apiRequest('/auth/verify-action', {
      method: 'POST',
      body: JSON.stringify({ totpCode: code }),
    });
    serverUrlUnlockVerify.classList.add('hidden');
    unlockServerUrl();
  } catch (err) {
    showError(serverUrlUnlockError, err.message);
  } finally {
    serverUrlUnlockBtn.disabled = false;
  }
});

serverUrlUnlockCancelBtn.addEventListener('click', () => {
  serverUrlUnlockVerify.classList.add('hidden');
  serverUrlUnlockInput.value = '';
  hideError(serverUrlUnlockError);
});

// ===== Clear Server & Re-push =====

clearServerBtn.addEventListener('click', async () => {
  // Show verification section instead of confirm()
  clearServerVerify.classList.remove('hidden');
  clearServerBtn.classList.add('hidden');
  hideError(clearVerifyError);
  clearVerifyInput.value = '';

  // Check if 2FA is enabled to show the right input
  try {
    const data = await apiRequest('/auth/2fa/status');
    const has2FA = data.twoFactor && data.twoFactor.enabled;

    if (has2FA) {
      clearVerifyInput.type = 'text';
      clearVerifyInput.placeholder = '123456';
      clearVerifyInput.inputMode = 'numeric';
      clearVerifyInput.maxLength = 6;
      clearVerifyPrompt.textContent = 'Enter your authenticator code:';
    } else {
      clearVerifyInput.type = 'password';
      clearVerifyInput.placeholder = 'Enter your password';
      clearVerifyInput.inputMode = '';
      clearVerifyInput.maxLength = 128;
      clearVerifyPrompt.textContent = 'Enter your password to continue:';
    }
  } catch {
    // Fallback to password
    clearVerifyInput.type = 'password';
    clearVerifyInput.placeholder = 'Enter your password';
    clearVerifyPrompt.textContent = 'Enter your password to continue:';
  }

  clearVerifyInput.focus();
});

clearVerifyBtn.addEventListener('click', async () => {
  const value = clearVerifyInput.value.trim();
  if (!value) {
    showError(clearVerifyError, 'Please enter your verification.');
    return;
  }

  clearVerifyBtn.disabled = true;
  hideError(clearVerifyError);

  try {
    // Build verify body based on input type
    const is2FA = clearVerifyInput.type === 'text';
    const body = is2FA ? { totpCode: value } : { password: value };

    // Step 1: Verify identity and get action token
    const verifyData = await apiRequest('/auth/verify-action', {
      method: 'POST',
      body: JSON.stringify(body),
    });

    const actionToken = verifyData.actionToken;

    // Step 2: Delete all server bookmarks with verified action token
    await apiRequest('/bookmarks', {
      method: 'DELETE',
      headers: { 'X-Action-Token': actionToken },
    });
    addLogEntry('Server bookmarks cleared', 'success');

    // Step 3: Clear local sync state
    await setStorage({ lastSyncTime: null, lastLocalBookmarkHashes: [] });

    // Step 4: Push fresh bookmarks
    const response = await sendMessageToBackground({ action: 'push' });
    if (response?.success) {
      addLogEntry(`Re-pushed ${response.count || 0} bookmarks to cloud`, 'success');
      await refreshStats();
    } else {
      throw new Error(response?.error || 'Push failed');
    }

    // Done — hide verification, show button
    clearServerVerify.classList.add('hidden');
    clearServerBtn.classList.remove('hidden');
  } catch (err) {
    showError(clearVerifyError, err.message);
  } finally {
    clearVerifyBtn.disabled = false;
  }
});

clearVerifyCancelBtn.addEventListener('click', () => {
  clearServerVerify.classList.add('hidden');
  clearServerBtn.classList.remove('hidden');
  hideError(clearVerifyError);
  clearVerifyInput.value = '';
});

// ===== Logout =====

async function performLogout() {
  const { refreshToken } = await getStorage(['refreshToken']);

  try {
    await apiRequest('/auth/logout', {
      method: 'POST',
      body: JSON.stringify({ refreshToken }),
    });
  } catch {
    // Ignore network errors on logout cleanup
  }

  await removeStorage(['token', 'refreshToken', 'user', 'lastSyncTime', 'lastLocalBookmarkHashes', 'boundServerUrlHash']);
  setSkippedInvalidBookmarks([]);
  resetTwoFactorState();
  showView(loginView);
  authForm.reset();
  hideError(authError);
}

logoutBtn.addEventListener('click', async () => {
  // Require TOTP verification before logout
  logoutVerify.classList.remove('hidden');
  logoutBtn.classList.add('hidden');
  hideError(logoutVerifyError);
  logoutVerifyInput.value = '';
  logoutVerifyInput.focus();
});

logoutVerifyBtn.addEventListener('click', async () => {
  const code = logoutVerifyInput.value.trim();
  if (!code) {
    showError(logoutVerifyError, 'Enter your authenticator code.');
    return;
  }
  logoutVerifyBtn.disabled = true;
  hideError(logoutVerifyError);
  try {
    await apiRequest('/auth/verify-action', {
      method: 'POST',
      body: JSON.stringify({ totpCode: code }),
    });
    logoutVerify.classList.add('hidden');
    logoutBtn.classList.remove('hidden');
    await performLogout();
  } catch (err) {
    showError(logoutVerifyError, err.message);
  } finally {
    logoutVerifyBtn.disabled = false;
  }
});

logoutVerifyCancelBtn.addEventListener('click', () => {
  logoutVerify.classList.add('hidden');
  logoutBtn.classList.remove('hidden');
  logoutVerifyInput.value = '';
  hideError(logoutVerifyError);
});

// ===== Settings =====

settingsBtn.addEventListener('click', async () => {
  const { autoSync, syncInterval, serverUrl, user, themeMode: savedThemeMode } = await getStorage([
    'autoSync',
    'syncInterval',
    'serverUrl',
    'user',
    'themeMode',
  ]);

  document.getElementById('autoSync').checked = autoSync !== false;
  document.getElementById('syncInterval').value = syncInterval || '15';
  document.getElementById('serverUrl').value = serverUrl || '';
  applyTheme(savedThemeMode || 'light');
  extensionVersionValue.textContent = `V${getExtensionVersion()}`;

  // Lock server URL when logged in
  if (user) {
    serverUrlLockBtn.classList.remove('hidden');
    lockServerUrl();
  } else {
    serverUrlLockBtn.classList.add('hidden');
    document.getElementById('serverUrl').disabled = false;
    document.getElementById('serverUrl').classList.remove('input-locked');
  }

  showView(settingsView);

  // Load 2FA status (async, non-blocking)
  refresh2faStatus();
});

backBtn.addEventListener('click', async () => {
  const { user } = await getStorage(['user']);
  if (user) {
    showDashboard(user);
  } else {
    showView(loginView);
  }
});

saveSettingsBtn.addEventListener('click', async () => {
  const autoSync = document.getElementById('autoSync').checked;
  const syncInterval = document.getElementById('syncInterval').value;
  const serverUrl = document.getElementById('serverUrl').value.replace(/\/+$/, '');
  const selectedThemeMode = themeMode.checked ? 'dark' : 'light';

  hideError(settingsError);
  try {
    const parsed = new URL(serverUrl);
    const isLocalhost = parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1';
    if (!isLocalhost && parsed.protocol !== 'https:') {
      showError(settingsError, 'Server URL must use HTTPS (except localhost).');
      return;
    }
  } catch {
    showError(settingsError, 'Please enter a valid server URL.');
    return;
  }

  await setStorage({ autoSync, syncInterval, serverUrl, themeMode: selectedThemeMode });
  applyTheme(selectedThemeMode);

  // Notify background to update alarm
  sendMessageToBackground({
    action: 'updateSettings',
    settings: { autoSync, syncInterval, serverUrl },
  });

  // Re-lock server URL after save
  const { user: savedUser } = await getStorage(['user']);
  if (savedUser) {
    lockServerUrl();
  }

  // Go back
  const { user } = await getStorage(['user']);
  if (user) {
    showDashboard(user);
  } else {
    showView(loginView);
  }
});

