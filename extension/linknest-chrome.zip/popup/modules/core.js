/**
 * LinkNest - Popup Script
 * Handles UI interactions, auth flow, and sync triggers
 */

// ===== DOM Elements =====
const loginView = document.getElementById('loginView');
const dashboardView = document.getElementById('dashboardView');
const settingsView = document.getElementById('settingsView');

const authForm = document.getElementById('authForm');
const authTabs = document.getElementById('authTabs');
const nameField = document.getElementById('nameField');
const twoFactorField = document.getElementById('twoFactorField');
const twoFactorCode = document.getElementById('twoFactorCode');
const cancelTwoFactorBtn = document.getElementById('cancelTwoFactorBtn');
const authError = document.getElementById('authError');
const authSubmit = document.getElementById('authSubmit');
const authBtnText = document.getElementById('authBtnText');
const authSpinner = document.getElementById('authSpinner');
const openPersistentLoginBtn = document.getElementById('openPersistentLoginBtn');

const userEmail = document.getElementById('userEmail');
const userAvatar = document.getElementById('userAvatar');
const syncStatus = document.getElementById('syncStatus');
const localCount = document.getElementById('localCount');
const serverCount = document.getElementById('serverCount');
const browserNameEl = document.getElementById('browserName');

const statsDuplicateHint = document.getElementById('statsDuplicateHint');

const syncNowBtn = document.getElementById('syncNowBtn');
const syncBtnText = document.getElementById('syncBtnText');
const syncSpinner = document.getElementById('syncSpinner');
const pushBtn = document.getElementById('pushBtn');
const pullBtn = document.getElementById('pullBtn');
const logoutBtn = document.getElementById('logoutBtn');
const clearServerBtn = document.getElementById('clearServerBtn');

const settingsBtn = document.getElementById('settingsBtn');
const backBtn = document.getElementById('backBtn');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const settingsError = document.getElementById('settingsError');
const themeMode = document.getElementById('themeMode');
const extensionVersionValue = document.getElementById('extensionVersionValue');

// Server URL lock elements
const serverUrlLockBtn = document.getElementById('serverUrlLockBtn');
const lockIconLocked = document.getElementById('lockIconLocked');
const lockIconUnlocked = document.getElementById('lockIconUnlocked');

// Clear Server verification elements
const clearServerVerify = document.getElementById('clearServerVerify');
const clearVerifyPrompt = document.getElementById('clearVerifyPrompt');
const clearVerifyInput = document.getElementById('clearVerifyInput');
const clearVerifyBtn = document.getElementById('clearVerifyBtn');
const clearVerifyCancelBtn = document.getElementById('clearVerifyCancelBtn');
const clearVerifyError = document.getElementById('clearVerifyError');

const syncLog = document.getElementById('syncLog');
const logEntries = document.getElementById('logEntries');
const exportSkippedInvalidBtn = document.getElementById('exportSkippedInvalidBtn');

// Organize elements
const organizeBtn = document.getElementById('organizeBtn');
const organizeBtnText = document.getElementById('organizeBtnText');
const organizeSpinner = document.getElementById('organizeSpinner');
const organizePreview = document.getElementById('organizePreview');
const organizeStats = document.getElementById('organizeStats');
const organizeCategories = document.getElementById('organizeCategories');
const organizeApplyBtn = document.getElementById('organizeApplyBtn');
const organizeCancelBtn = document.getElementById('organizeCancelBtn');

// Duplicate review elements
const reviewDuplicatesBtn = document.getElementById('reviewDuplicatesBtn');
const reviewDuplicatesBtnText = document.getElementById('reviewDuplicatesBtnText');
const duplicateReviewPanel = document.getElementById('duplicateReviewPanel');
const duplicateReviewStats = document.getElementById('duplicateReviewStats');
const duplicateGroupsList = document.getElementById('duplicateGroupsList');
const duplicateRemoveSelectedBtn = document.getElementById('duplicateRemoveSelectedBtn');
const duplicateReviewCancelBtn = document.getElementById('duplicateReviewCancelBtn');

// Logout verification elements
const logoutVerify = document.getElementById('logoutVerify');
const logoutVerifyInput = document.getElementById('logoutVerifyInput');
const logoutVerifyBtn = document.getElementById('logoutVerifyBtn');
const logoutVerifyCancelBtn = document.getElementById('logoutVerifyCancelBtn');
const logoutVerifyError = document.getElementById('logoutVerifyError');

// Server URL unlock verification elements
const serverUrlUnlockVerify = document.getElementById('serverUrlUnlockVerify');
const serverUrlUnlockInput = document.getElementById('serverUrlUnlockInput');
const serverUrlUnlockBtn = document.getElementById('serverUrlUnlockBtn');
const serverUrlUnlockCancelBtn = document.getElementById('serverUrlUnlockCancelBtn');
const serverUrlUnlockError = document.getElementById('serverUrlUnlockError');

let currentAuthMode = 'login';
let pendingTwoFactorChallenge = null;
let pendingRegistrationSetupToken = null;
let pendingRegistrationUser = null;
let pendingResetToken = null;
let serverUrlLockTimeout = null;
let lastSkippedInvalidBookmarks = [];

// Registration TOTP setup elements
const regTotpSetup = document.getElementById('regTotpSetup');
const regTotpQrImage = document.getElementById('regTotpQrImage');
const regTotpSecret = document.getElementById('regTotpSecret');
const regSecretKeyBox = document.getElementById('regSecretKeyBox');
const regToggleSecretBtn = document.getElementById('regToggleSecretBtn');
const regCopySecretBtn = document.getElementById('regCopySecretBtn');
const regTotpVerifyCode = document.getElementById('regTotpVerifyCode');
const regVerify2faBtn = document.getElementById('regVerify2faBtn');
const regSetupError = document.getElementById('regSetupError');
const regBackupCodes = document.getElementById('regBackupCodes');
const regBackupCodesList = document.getElementById('regBackupCodesList');
const regDismissBackupBtn = document.getElementById('regDismissBackupBtn');

// Confirm password field
const confirmPasswordField = document.getElementById('confirmPasswordField');
const confirmPasswordInput = document.getElementById('confirmPassword');

// Login heading elements
const loginTitle = document.getElementById('loginTitle');
const loginSubtitle = document.getElementById('loginSubtitle');

// Reset password elements
const forgotPasswordBtn = document.getElementById('forgotPasswordBtn');
const resetPasswordView = document.getElementById('resetPasswordView');
const resetStep1 = document.getElementById('resetStep1');
const resetStep2 = document.getElementById('resetStep2');
const resetEmail = document.getElementById('resetEmail');
const resetTotp = document.getElementById('resetTotp');
const resetVerifyBtn = document.getElementById('resetVerifyBtn');
const resetNewPassword = document.getElementById('resetNewPassword');
const resetConfirmPassword = document.getElementById('resetConfirmPassword');
const resetSubmitBtn = document.getElementById('resetSubmitBtn');
const resetCancelBtn = document.getElementById('resetCancelBtn');
const resetStep1Error = document.getElementById('resetStep1Error');
const resetStep2Error = document.getElementById('resetStep2Error');

const permissionBanner = document.getElementById('permissionBanner');
const grantPermissionBtn = document.getElementById('grantPermissionBtn');

const linkNestClient = window.LinkNestClient;

if (!linkNestClient) {
  throw new Error('Shared LinkNest client helpers failed to load.');
}

// ===== Server URL Binding Helpers =====

async function hashString(str) {
  return linkNestClient.hashString(str);
}

async function verifyServerUrlBinding() {
  return linkNestClient.verifyServerUrlBinding();
}

// ===== Permission Request Helper =====
// Host permissions are NOT required — the server uses CORS with
// Access-Control-Allow-Origin for extension origins, and the CSP
// connect-src already allows https:/http connections.  Requesting
// optional host permissions triggers a scary "Read and change your
// data" prompt that confuses users.  We keep the function signature
// so callers don't need to change, but it always succeeds.

async function requestHostPermission(_serverUrl) {
  return true;
}

// ===== Utility Functions =====

/**
 * Cross-browser sendMessage wrapper.
 * Firefox MV2 'chrome.runtime.sendMessage' is callback-based;
 * 'browser.runtime.sendMessage' returns a Promise.
 * Chrome MV3 'chrome.runtime.sendMessage' returns a Promise.
 */
function sendMessageToBackground(msg) {
  if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage) {
    return browser.runtime.sendMessage(msg);
  }
  return chrome.runtime.sendMessage(msg);
}

function showView(view) {
  [loginView, dashboardView, settingsView].forEach((v) => v.classList.add('hidden'));
  view.classList.remove('hidden');
}

function showError(el, message) {
  el.textContent = message;
  el.classList.remove('hidden');
}

function hideError(el) {
  el.classList.add('hidden');
}

function setLoading(btn, spinner, textEl, loading, text) {
  btn.disabled = loading;
  spinner.classList.toggle('hidden', !loading);
  textEl.textContent = text || textEl.textContent;
}

function resetTwoFactorState() {
  pendingTwoFactorChallenge = null;
  pendingRegistrationSetupToken = null;
  pendingRegistrationUser = null;
  pendingResetToken = null;
  twoFactorField.classList.add('hidden');
  twoFactorCode.value = '';
  document.getElementById('email').disabled = false;
  document.getElementById('password').disabled = false;
  nameField.classList.toggle('hidden', currentAuthMode === 'login');
  confirmPasswordField.classList.toggle('hidden', currentAuthMode === 'login');
  authTabs.classList.remove('hidden');
  authForm.classList.remove('hidden');
  authBtnText.textContent = currentAuthMode === 'login' ? 'Login' : 'Register';
  // Hide registration TOTP setup
  regTotpSetup.classList.add('hidden');
  regBackupCodes.classList.add('hidden');
  regSetupError.classList.add('hidden');
  // Hide reset password view
  resetPasswordView.classList.add('hidden');
  forgotPasswordBtn.classList.toggle('hidden', currentAuthMode !== 'login');
  loginTitle.classList.remove('hidden');
  loginSubtitle.classList.remove('hidden');
}

function addLogEntry(message, type = 'info') {
  syncLog.classList.remove('hidden');
  const entry = document.createElement('div');
  entry.className = `log-entry ${type}`;
  const time = new Date().toLocaleTimeString();
  const messageSpan = document.createElement('span');
  messageSpan.textContent = message;
  const timeSpan = document.createElement('span');
  timeSpan.className = 'log-time';
  timeSpan.textContent = time;
  entry.appendChild(messageSpan);
  entry.appendChild(timeSpan);
  logEntries.prepend(entry);

  // Keep only last 20 entries
  while (logEntries.children.length > 20) {
    logEntries.removeChild(logEntries.lastChild);
  }
}

function setSkippedInvalidBookmarks(entries = []) {
  lastSkippedInvalidBookmarks = Array.isArray(entries) ? entries : [];
  exportSkippedInvalidBtn.classList.toggle('hidden', lastSkippedInvalidBookmarks.length === 0);
}

function csvEscape(value) {
  const stringValue = value == null ? '' : String(value);
  const trimmedLeading = stringValue.trimStart();
  const safeValue = /^[=+\-@]/.test(trimmedLeading) ? `'${stringValue}` : stringValue;
  return `"${safeValue.replace(/"/g, '""')}"`;
}

function exportSkippedInvalidBookmarksCsv() {
  if (!Array.isArray(lastSkippedInvalidBookmarks) || lastSkippedInvalidBookmarks.length === 0) {
    addLogEntry('No skipped invalid bookmark URLs to export', 'info');
    return;
  }

  const rows = [
    ['Title', 'URL', 'Folder Path', 'Reason'],
    ...lastSkippedInvalidBookmarks.map((entry) => [
      entry.title || '',
      entry.url || '',
      entry.folderPath || 'root',
      entry.reason || 'non-http-https-url',
    ]),
  ];

  const csvContent = rows.map((row) => row.map(csvEscape).join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `linknest-skipped-invalid-urls-${timestamp}.csv`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
  addLogEntry(`Exported ${lastSkippedInvalidBookmarks.length} skipped invalid URL(s)`, 'success');
}

function handleSkippedInvalidBookmarksResponse(response) {
  const skippedCount = Number(response?.skippedInvalidUrls || 0);
  const skippedList = Array.isArray(response?.skippedInvalidBookmarkUrls)
    ? response.skippedInvalidBookmarkUrls
    : [];

  if (skippedCount > 0) {
    addLogEntry(`Skipped ${skippedCount} invalid (non-HTTP/HTTPS) bookmark URL(s)`, 'info');
    setSkippedInvalidBookmarks(skippedList);
  } else {
    setSkippedInvalidBookmarks([]);
  }
}

exportSkippedInvalidBtn.addEventListener('click', () => {
  exportSkippedInvalidBookmarksCsv();
});

function detectBrowser() {
  const ua = navigator.userAgent;
  if (ua.includes('Firefox')) return 'Firefox';
  if (ua.includes('Edg/')) return 'Edge';
  if (ua.includes('Brave')) return 'Brave';
  if (ua.includes('OPR') || ua.includes('Opera')) return 'Opera';
  if (ua.includes('Chrome')) return 'Chrome';
  if (ua.includes('Safari')) return 'Safari';
  return 'Unknown';
}

function isStandalonePopupPage() {
  try {
    const params = new URLSearchParams(window.location.search);
    return params.get('standalone') === '1';
  } catch {
    return false;
  }
}

function getExtensionPageUrl(path) {
  if (typeof browser !== 'undefined' && browser.runtime?.getURL) {
    return browser.runtime.getURL(path);
  }
  return chrome.runtime.getURL(path);
}

function setupPersistentLoginHelper() {
  const browserName = detectBrowser();
  const standalone = isStandalonePopupPage();
  if (standalone) {
    document.body.classList.add('standalone');
  }

  const shouldShow = browserName === 'Firefox' && !standalone;
  openPersistentLoginBtn.classList.toggle('hidden', !shouldShow);
}

openPersistentLoginBtn.addEventListener('click', () => {
  const url = getExtensionPageUrl('popup/popup.html?standalone=1');
  window.open(url, '_blank', 'noopener');
});

function getExtensionVersion() {
  try {
    if (typeof browser !== 'undefined' && browser.runtime?.getManifest) {
      return browser.runtime.getManifest().version;
    }
    return chrome.runtime.getManifest().version;
  } catch {
    return 'unknown';
  }
}

function applyTheme(mode) {
  const resolved = mode === 'dark' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', resolved);
  if (themeMode) {
    themeMode.checked = resolved === 'dark';
  }
}

// ===== Storage Helpers =====

async function getStorage(keys) {
  return linkNestClient.getStorage(keys);
}

async function setStorage(data) {
  return linkNestClient.setStorage(data);
}

async function removeStorage(keys) {
  return linkNestClient.removeStorage(keys);
}

/**
 * Cross-browser bookmarks.getTree wrapper.
 * Firefox MV2 'chrome.bookmarks.getTree()' is callback-based (returns undefined).
 * 'browser.bookmarks.getTree()' returns a Promise.
 * Chrome MV3 'chrome.bookmarks.getTree()' returns a Promise.
 */
function getBookmarksTree() {
  if (typeof browser !== 'undefined' && browser.bookmarks && browser.bookmarks.getTree) {
    return browser.bookmarks.getTree();
  }
  // Chrome MV3: returns a Promise
  return chrome.bookmarks.getTree();
}

// ===== API Helpers =====

async function getServerUrl() {
  return linkNestClient.getServerUrl();
}

async function apiRequest(endpoint, options = {}, allowRefresh = true) {
  return linkNestClient.apiRequest(endpoint, options, {
    allowRefresh,
    onSessionExpired: async () => {
      resetTwoFactorState();
      showView(loginView);
      authForm.reset();
      hideError(authError);
    },
  });
}

