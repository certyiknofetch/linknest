// ===== Auth =====

authTabs.addEventListener('click', (e) => {
  const tab = e.target.closest('.tab');
  if (!tab) return;

  currentAuthMode = tab.dataset.tab;
  resetTwoFactorState();
  authTabs.querySelectorAll('.tab').forEach((t) => {
    t.classList.remove('active');
    t.setAttribute('aria-selected', 'false');
  });
  tab.classList.add('active');
  tab.setAttribute('aria-selected', 'true');

  nameField.classList.toggle('hidden', currentAuthMode === 'login');
  confirmPasswordField.classList.toggle('hidden', currentAuthMode === 'login');
  forgotPasswordBtn.classList.toggle('hidden', currentAuthMode !== 'login');
  authBtnText.textContent = currentAuthMode === 'login' ? 'Login' : 'Register';
  hideError(authError);
});

cancelTwoFactorBtn.addEventListener('click', () => {
  resetTwoFactorState();
  hideError(authError);
});

authForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  hideError(authError);

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const name = document.getElementById('name').value.trim();
  const confirmPw = confirmPasswordInput.value;
  const enteredTwoFactorCode = twoFactorCode.value.trim();

  if (!email || !password) {
    showError(authError, 'Please fill in all fields.');
    return;
  }

  // Validate confirm password on register
  if (currentAuthMode === 'register' && !pendingTwoFactorChallenge) {
    if (!confirmPw) {
      showError(authError, 'Please confirm your password.');
      return;
    }
    if (password !== confirmPw) {
      showError(authError, 'Passwords do not match.');
      return;
    }
  }

  setLoading(authSubmit, authSpinner, authBtnText, true);

  try {
    let endpoint = currentAuthMode === 'login' ? '/auth/login' : '/auth/register';
    let body = { email, password };

    if (pendingTwoFactorChallenge) {
      endpoint = '/auth/2fa/verify-login';
      body = {
        challengeToken: pendingTwoFactorChallenge,
        totpCode: enteredTwoFactorCode,
      };

      if (!enteredTwoFactorCode) {
        throw new Error('Please enter your authenticator code.');
      }
    } else if (currentAuthMode === 'register' && name) {
      body.name = name;
    }

    const data = await apiRequest(endpoint, {
      method: 'POST',
      body: JSON.stringify(body),
    });

    if (data.requiresTwoFactor) {
      pendingTwoFactorChallenge = data.challengeToken;
      twoFactorField.classList.remove('hidden');
      authTabs.classList.add('hidden');
      nameField.classList.add('hidden');
      document.getElementById('email').disabled = true;
      document.getElementById('password').disabled = true;
      authBtnText.textContent = 'Verify 2FA';
      twoFactorCode.focus();
      return;
    }

    // Registration returns requiresTotpSetup — show QR setup
    if (data.requiresTotpSetup) {
      pendingRegistrationSetupToken = data.setupToken;
      authForm.classList.add('hidden');
      authTabs.classList.add('hidden');

      // Show QR code
      if (data.qrDataUrl) {
        regTotpQrImage.src = data.qrDataUrl;
        regTotpQrImage.classList.remove('hidden');
      }
      regTotpSecret.textContent = data.secret;
      regSecretKeyBox.classList.add('hidden');
      regTotpSetup.classList.remove('hidden');
      regTotpVerifyCode.value = '';
      regTotpVerifyCode.focus();
      return;
    }

    // Save auth data + bind the server URL to this session
    const loginServerUrl = await getServerUrl();
    const boundHash = await hashString(loginServerUrl);
    await setStorage({
      user: data.user,
      boundServerUrlHash: boundHash,
    });
    await removeStorage(['token', 'refreshToken']);

    resetTwoFactorState();

    showDashboard(data.user);
  } catch (err) {
    showError(authError, err.message);
  } finally {
    setLoading(authSubmit, authSpinner, authBtnText, false, currentAuthMode === 'login' ? 'Login' : 'Register');
  }
});

// ===== Dashboard =====

async function showDashboard(user) {
  showView(dashboardView);

  userEmail.textContent = user.email;
  userAvatar.textContent = (user.name || user.email)[0].toUpperCase();

  const browser = detectBrowser();
  browserNameEl.textContent = browser;
  await setStorage({ browserName: browser });

  await refreshStats();
}

async function refreshStats() {
  try {
    const tree = await getBookmarksTree();
    const count = countBookmarks(tree);
    localCount.textContent = count;

    const { lastSyncTime } = await getStorage(['lastSyncTime']);
    if (lastSyncTime) {
      syncStatus.textContent = `Last synced: ${new Date(lastSyncTime).toLocaleString()}`;
    }

    let cloudCount = null;
    try {
      const data = await apiRequest('/bookmarks');
      cloudCount = data.bookmarks.length;
      serverCount.textContent = cloudCount;
    } catch {
      serverCount.textContent = '?';
    }

    if (cloudCount !== null && count > cloudCount) {
      const diff = count - cloudCount;
      statsDuplicateHint.textContent =
        `Local has ${diff} more — likely duplicate URLs in multiple folders (cloud stores one per URL)`;
      statsDuplicateHint.classList.remove('hidden');
    } else {
      statsDuplicateHint.classList.add('hidden');
    }

    // Also check for local duplicates to show/hide the Review Duplicates button
    try {
      const dupeResp = await sendMessageToBackground({ action: 'detectDuplicates' });
      if (dupeResp?.success) {
        updateReviewDuplicatesButton(dupeResp.count || 0);
      }
    } catch {}
  } catch (err) {
    console.error('Failed to refresh stats:', err);
  }
}

function countBookmarks(nodes) {
  let count = 0;
  for (const node of nodes) {
    if (node.url) count++;
    if (node.children) count += countBookmarks(node.children);
  }
  return count;
}

// ===== Sync Actions =====

async function ensureServerUrlBound() {
  const valid = await verifyServerUrlBinding();
  if (!valid) {
    throw new Error('Server URL has changed since login. Please log out and log in again to sync.');
  }
}

function handleDuplicateInfo(response) {
  const collapsed = Number(response.duplicatesCollapsed || 0);
  const localDupes = Number(response.localDuplicateCount || 0);
  if (collapsed > 0) {
    addLogEntry(
      `${collapsed} duplicate URL(s) merged on cloud (cloud stores one per URL)`,
      'info'
    );
  }
  updateReviewDuplicatesButton(localDupes);
}

syncNowBtn.addEventListener('click', async () => {
  setLoading(syncNowBtn, syncSpinner, syncBtnText, true, 'Syncing...');
  try {
    await ensureServerUrlBound();
    const response = await sendMessageToBackground({ action: 'sync' });
    if (response?.success) {
      const created = Number(response.created || 0);
      const updated = Number(response.updated || 0);
      const pulled = Number(response.pulled || 0);
      const remoteUpdated = Number(response.remoteUpdated || 0);
      const removed = Number(response.removed || 0);
      addLogEntry(
        `Synced: ${created} new, ${updated} updated` +
        (pulled > 0 ? `, pulled ${pulled}` : '') +
        (remoteUpdated > 0 ? `, remote-updated ${remoteUpdated}` : '') +
        (removed > 0 ? `, removed ${removed}` : ''),
        'success'
      );
      if (Number(response.applyErrors || 0) > 0) {
        addLogEntry(
          `Sync apply warnings: ${response.applyErrors} of ${response.serverBookmarks || 0} cloud bookmarks failed to apply`,
          'error'
        );
      }
      handleDuplicateInfo(response);
      handleSkippedInvalidBookmarksResponse(response);
      await setStorage({ lastSyncTime: new Date().toISOString() });
      await refreshStats();
    } else {
      const errMsg = response?.error || response?.message || 'Sync failed (no details)';
      throw new Error(errMsg);
    }
  } catch (err) {
    addLogEntry(`Error: ${err.message}`, 'error');
    console.error('LinkNest sync error:', err);
  } finally {
    setLoading(syncNowBtn, syncSpinner, syncBtnText, false, 'Sync Now');
  }
});

pushBtn.addEventListener('click', async () => {
  pushBtn.disabled = true;
  try {
    await ensureServerUrlBound();
    const response = await sendMessageToBackground({ action: 'push' });
    if (response?.success) {
      addLogEntry(`Pushed ${response.count || 0} bookmarks to cloud`, 'success');
      handleSkippedInvalidBookmarksResponse(response);
      await refreshStats();
    } else {
      const errMsg = response?.error || response?.message || 'Push failed (no details)';
      throw new Error(errMsg);
    }
  } catch (err) {
    addLogEntry(`Push error: ${err.message}`, 'error');
    console.error('LinkNest push error:', err);
  } finally {
    pushBtn.disabled = false;
  }
});

pullBtn.addEventListener('click', async () => {
  pullBtn.disabled = true;
  try {
    await ensureServerUrlBound();
    const response = await sendMessageToBackground({ action: 'pull' });
    if (response?.success) {
      const added = Number(response.count || 0);
      const updated = Number(response.updated || 0);
      const deleted = Number(response.deleted || 0);
      const applyErrors = Number(response.applyErrors || 0);
      addLogEntry(
        `Pulled ${added} bookmarks from cloud` +
        (updated > 0 ? `, updated ${updated}` : '') +
        (deleted > 0 ? `, removed ${deleted}` : '') +
        (applyErrors > 0 ? `, failed ${applyErrors}` : ''),
        'success'
      );
      if (applyErrors > 0) {
        addLogEntry(
          `Pull apply warnings: ${applyErrors} of ${response.serverBookmarks || 0} cloud bookmarks failed to apply`,
          'error'
        );
      }
      await refreshStats();
    } else {
      const errMsg = response?.error || response?.message || 'Pull failed (no details)';
      throw new Error(errMsg);
    }
  } catch (err) {
    addLogEntry(`Pull error: ${err.message}`, 'error');
    console.error('LinkNest pull error:', err);
  } finally {
    pullBtn.disabled = false;
  }
});

// ===== Organize =====

let pendingOrganizeData = null;

organizeBtn.addEventListener('click', async () => {
  setLoading(organizeBtn, organizeSpinner, organizeBtnText, true, 'Analyzing...');
  organizePreview.classList.add('hidden');
  pendingOrganizeData = null;

  try {
    await ensureServerUrlBound();

    // Get categorization from background (which has local bookmarks + calls server)
    const response = await sendMessageToBackground({ action: 'categorize' });

    if (!response?.success) {
      throw new Error(response?.error || 'Categorization failed');
    }

    pendingOrganizeData = response.categories;
    const stats = response.stats;

    // Show stats
    const parts = [`${stats.total} bookmarks analyzed`];
    if (stats.byDomain > 0) parts.push(`${stats.byDomain} by domain`);
    if (stats.byAI > 0) parts.push(`${stats.byAI} by AI`);
    if ((stats.aiFailedBatches || 0) > 0) parts.push(`AI fallback on ${stats.aiFailedBatches} batch(es)`);
    if (stats.uncategorized > 0) parts.push(`${stats.uncategorized} uncategorized`);
    if ((stats.organizeExcluded || 0) > 0) parts.push(`${stats.organizeExcluded} skipped from '-' folders`);
    if ((stats.learnedDomains || 0) > 0) parts.push(`${stats.learnedDomains} domain rules learned`);
    if (!stats.aiEnabled) parts.push('AI not configured — domain-only mode');
    organizeStats.textContent = parts.join(' · ');

    // Build category list
    organizeCategories.innerHTML = '';
    const createFolderIcon = () => {
      const svgNs = 'http://www.w3.org/2000/svg';
      const svg = document.createElementNS(svgNs, 'svg');
      svg.setAttribute('width', '14');
      svg.setAttribute('height', '14');
      svg.setAttribute('viewBox', '0 0 24 24');
      svg.setAttribute('fill', 'none');
      svg.setAttribute('stroke', 'currentColor');
      svg.setAttribute('stroke-width', '2');

      const path = document.createElementNS(svgNs, 'path');
      path.setAttribute('d', 'M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z');
      svg.appendChild(path);
      return svg;
    };

    for (const [category, bookmarks] of Object.entries(pendingOrganizeData)) {
      const row = document.createElement('div');
      row.className = 'organize-category';

      const nameEl = document.createElement('div');
      nameEl.className = 'cat-name';
      const iconEl = document.createElement('span');
      iconEl.className = 'cat-icon';
      iconEl.appendChild(createFolderIcon());
      const labelEl = document.createElement('span');
      labelEl.textContent = category;
      nameEl.appendChild(iconEl);
      nameEl.appendChild(labelEl);

      const countEl = document.createElement('span');
      countEl.className = 'cat-count';
      countEl.textContent = bookmarks.length;

      row.appendChild(nameEl);
      row.appendChild(countEl);

      // Expandable items list
      const itemsEl = document.createElement('div');
      itemsEl.className = 'cat-items';
      const maxShow = 8;
      bookmarks.slice(0, maxShow).forEach((bm) => {
        const item = document.createElement('div');
        item.className = 'cat-item';
        item.textContent = bm.title || bm.url;
        item.title = bm.url;
        itemsEl.appendChild(item);
      });
      if (bookmarks.length > maxShow) {
        const more = document.createElement('div');
        more.className = 'cat-item';
        more.textContent = `... and ${bookmarks.length - maxShow} more`;
        more.style.fontStyle = 'italic';
        itemsEl.appendChild(more);
      }

      row.addEventListener('click', () => {
        row.classList.toggle('expanded');
      });

      const wrapper = document.createElement('div');
      wrapper.appendChild(row);
      wrapper.appendChild(itemsEl);
      organizeCategories.appendChild(wrapper);
    }

    organizePreview.classList.remove('hidden');
    addLogEntry(`Categorized ${stats.total} bookmarks into ${Object.keys(pendingOrganizeData).length} folders`, 'info');
  } catch (err) {
    addLogEntry(`Organize error: ${err.message}`, 'error');
    console.error('LinkNest organize error:', err);
  } finally {
    setLoading(organizeBtn, organizeSpinner, organizeBtnText, false, 'Organize');
  }
});

organizeApplyBtn.addEventListener('click', async () => {
  if (!pendingOrganizeData) return;

  organizeApplyBtn.disabled = true;
  organizeCancelBtn.disabled = true;

  try {
    await ensureServerUrlBound();

    const response = await sendMessageToBackground({
      action: 'applyOrganize',
      categories: pendingOrganizeData,
    });

    if (!response?.success) {
      throw new Error(response?.error || 'Failed to apply organization');
    }

    const removedEmptyFolders = Number(response.removedEmptyFolders || 0);
    const organizeSummary = `Organized: moved ${response.moved || 0} bookmarks into ${response.foldersCreated || 0} folders${removedEmptyFolders > 0 ? `, removed ${removedEmptyFolders} empty folders` : ''}`;
    addLogEntry(organizeSummary, 'success');
    organizePreview.classList.add('hidden');
    pendingOrganizeData = null;

    // Trigger sync after organizing
    try {
      const syncResp = await sendMessageToBackground({ action: 'sync' });
      if (syncResp?.success) {
        addLogEntry('Synced after organize', 'success');
        handleSkippedInvalidBookmarksResponse(syncResp);
      }
    } catch {}

    await refreshStats();
  } catch (err) {
    addLogEntry(`Apply error: ${err.message}`, 'error');
    console.error('LinkNest apply organize error:', err);
  } finally {
    organizeApplyBtn.disabled = false;
    organizeCancelBtn.disabled = false;
  }
});

organizeCancelBtn.addEventListener('click', () => {
  organizePreview.classList.add('hidden');
  pendingOrganizeData = null;
  addLogEntry('Organize cancelled', 'info');
});

// ===== Duplicate Review =====

let pendingDuplicateRemovals = new Map();

function updateReviewDuplicatesButton(localDuplicateCount) {
  if (localDuplicateCount > 0) {
    reviewDuplicatesBtnText.textContent = `Review ${localDuplicateCount} Duplicate(s)`;
    reviewDuplicatesBtn.classList.remove('hidden');
  } else {
    reviewDuplicatesBtn.classList.add('hidden');
    duplicateReviewPanel.classList.add('hidden');
  }
}

reviewDuplicatesBtn.addEventListener('click', async () => {
  reviewDuplicatesBtn.disabled = true;
  pendingDuplicateRemovals = new Map();

  try {
    const response = await sendMessageToBackground({ action: 'detectDuplicates' });
    if (!response?.success || !Array.isArray(response.groups) || response.groups.length === 0) {
      addLogEntry('No local duplicate bookmarks found.', 'info');
      reviewDuplicatesBtn.classList.add('hidden');
      return;
    }

    const groups = response.groups;
    const totalExtras = groups.reduce((sum, g) => sum + (g.bookmarks.length - 1), 0);
    duplicateReviewStats.textContent =
      `${groups.length} URL(s) bookmarked in multiple folders (${totalExtras} extra copies). ` +
      `Select which copy to keep for each — the others will be removed from your browser.`;

    duplicateGroupsList.innerHTML = '';

    for (const group of groups) {
      const wrapper = document.createElement('div');
      wrapper.className = 'duplicate-group';

      const urlLabel = document.createElement('div');
      urlLabel.className = 'duplicate-url';
      urlLabel.textContent = group.bookmarks[0].title || group.url;
      urlLabel.title = group.url;
      wrapper.appendChild(urlLabel);

      const optionsEl = document.createElement('div');
      optionsEl.className = 'duplicate-options';

      for (const bm of group.bookmarks) {
        const option = document.createElement('label');
        option.className = 'duplicate-option';

        const radio = document.createElement('input');
        radio.type = 'radio';
        radio.name = `dup_${group.url}`;
        radio.value = bm.localId;

        radio.addEventListener('change', () => {
          const toRemove = group.bookmarks
            .filter((b) => b.localId !== bm.localId)
            .map((b) => b.localId);
          pendingDuplicateRemovals.set(group.url, toRemove);
        });

        const folderSpan = document.createElement('span');
        folderSpan.className = 'duplicate-folder';
        folderSpan.textContent = bm.folderPath || '(root)';

        option.appendChild(radio);
        option.appendChild(folderSpan);
        optionsEl.appendChild(option);
      }

      // "Keep all" option
      const keepAllOption = document.createElement('label');
      keepAllOption.className = 'duplicate-option';
      const keepAllRadio = document.createElement('input');
      keepAllRadio.type = 'radio';
      keepAllRadio.name = `dup_${group.url}`;
      keepAllRadio.value = '__keep_all__';
      keepAllRadio.checked = true;
      keepAllRadio.addEventListener('change', () => {
        pendingDuplicateRemovals.delete(group.url);
      });
      const keepAllSpan = document.createElement('span');
      keepAllSpan.className = 'duplicate-folder keep-all';
      keepAllSpan.textContent = 'Keep all copies';
      keepAllOption.appendChild(keepAllRadio);
      keepAllOption.appendChild(keepAllSpan);
      optionsEl.appendChild(keepAllOption);

      wrapper.appendChild(optionsEl);
      duplicateGroupsList.appendChild(wrapper);
    }

    duplicateReviewPanel.classList.remove('hidden');
  } catch (err) {
    addLogEntry(`Duplicate review error: ${err.message}`, 'error');
  } finally {
    reviewDuplicatesBtn.disabled = false;
  }
});

duplicateRemoveSelectedBtn.addEventListener('click', async () => {
  const localIdsToRemove = [];
  for (const ids of pendingDuplicateRemovals.values()) {
    localIdsToRemove.push(...ids);
  }

  if (localIdsToRemove.length === 0) {
    addLogEntry('No duplicates selected for removal.', 'info');
    duplicateReviewPanel.classList.add('hidden');
    return;
  }

  duplicateRemoveSelectedBtn.disabled = true;
  duplicateReviewCancelBtn.disabled = true;

  try {
    const response = await sendMessageToBackground({
      action: 'removeDuplicates',
      localIds: localIdsToRemove,
    });

    if (!response?.success) {
      throw new Error(response?.error || 'Failed to remove duplicates');
    }

    addLogEntry(
      `Removed ${response.removed || 0} duplicate bookmark(s)` +
      (response.failed > 0 ? `, ${response.failed} failed` : ''),
      'success'
    );

    duplicateReviewPanel.classList.add('hidden');
    pendingDuplicateRemovals = new Map();

    try {
      const syncResp = await sendMessageToBackground({ action: 'sync' });
      if (syncResp?.success) {
        addLogEntry('Synced after duplicate cleanup', 'success');
        handleDuplicateInfo(syncResp);
      }
    } catch {}

    await refreshStats();
  } catch (err) {
    addLogEntry(`Remove duplicates error: ${err.message}`, 'error');
  } finally {
    duplicateRemoveSelectedBtn.disabled = false;
    duplicateReviewCancelBtn.disabled = false;
  }
});

duplicateReviewCancelBtn.addEventListener('click', () => {
  duplicateReviewPanel.classList.add('hidden');
  pendingDuplicateRemovals = new Map();
});

