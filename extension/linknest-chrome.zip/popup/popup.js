/**
 * LinkNest - Popup Script
 * Handles UI interactions, auth flow, and sync triggers
 */

// ===== DOM Elements =====
const loginView = document.getElementById('loginView');
const dashboardView = document.getElementById('dashboardView');
const settingsView = document.getElementById('settingsView');

const authForm = document.getElementById('authForm');
const authTabs = document.getElementById('authTabs');
const nameField = document.getElementById('nameField');
const twoFactorField = document.getElementById('twoFactorField');
const twoFactorCode = document.getElementById('twoFactorCode');
const cancelTwoFactorBtn = document.getElementById('cancelTwoFactorBtn');
const authError = document.getElementById('authError');
const authSubmit = document.getElementById('authSubmit');
const authBtnText = document.getElementById('authBtnText');
const authSpinner = document.getElementById('authSpinner');

const userEmail = document.getElementById('userEmail');
const userAvatar = document.getElementById('userAvatar');
const syncStatus = document.getElementById('syncStatus');
const localCount = document.getElementById('localCount');
const serverCount = document.getElementById('serverCount');
const browserNameEl = document.getElementById('browserName');

const syncNowBtn = document.getElementById('syncNowBtn');
const syncBtnText = document.getElementById('syncBtnText');
const syncSpinner = document.getElementById('syncSpinner');
const pushBtn = document.getElementById('pushBtn');
const pullBtn = document.getElementById('pullBtn');
const logoutBtn = document.getElementById('logoutBtn');
const clearServerBtn = document.getElementById('clearServerBtn');

const settingsBtn = document.getElementById('settingsBtn');
const backBtn = document.getElementById('backBtn');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');

// Server URL lock elements
const serverUrlLockBtn = document.getElementById('serverUrlLockBtn');
const lockIconLocked = document.getElementById('lockIconLocked');
const lockIconUnlocked = document.getElementById('lockIconUnlocked');

// Clear Server verification elements
const clearServerVerify = document.getElementById('clearServerVerify');
const clearVerifyPrompt = document.getElementById('clearVerifyPrompt');
const clearVerifyInput = document.getElementById('clearVerifyInput');
const clearVerifyBtn = document.getElementById('clearVerifyBtn');
const clearVerifyCancelBtn = document.getElementById('clearVerifyCancelBtn');
const clearVerifyError = document.getElementById('clearVerifyError');

const syncLog = document.getElementById('syncLog');
const logEntries = document.getElementById('logEntries');

// Organize elements
const organizeBtn = document.getElementById('organizeBtn');
const organizeBtnText = document.getElementById('organizeBtnText');
const organizeSpinner = document.getElementById('organizeSpinner');
const organizePreview = document.getElementById('organizePreview');
const organizeStats = document.getElementById('organizeStats');
const organizeCategories = document.getElementById('organizeCategories');
const organizeApplyBtn = document.getElementById('organizeApplyBtn');
const organizeCancelBtn = document.getElementById('organizeCancelBtn');

// Logout verification elements
const logoutVerify = document.getElementById('logoutVerify');
const logoutVerifyInput = document.getElementById('logoutVerifyInput');
const logoutVerifyBtn = document.getElementById('logoutVerifyBtn');
const logoutVerifyCancelBtn = document.getElementById('logoutVerifyCancelBtn');
const logoutVerifyError = document.getElementById('logoutVerifyError');

// Server URL unlock verification elements
const serverUrlUnlockVerify = document.getElementById('serverUrlUnlockVerify');
const serverUrlUnlockInput = document.getElementById('serverUrlUnlockInput');
const serverUrlUnlockBtn = document.getElementById('serverUrlUnlockBtn');
const serverUrlUnlockCancelBtn = document.getElementById('serverUrlUnlockCancelBtn');
const serverUrlUnlockError = document.getElementById('serverUrlUnlockError');

let currentAuthMode = 'login';
let pendingTwoFactorChallenge = null;
let pendingRegistrationSetupToken = null;
let pendingRegistrationUser = null;
let pendingResetToken = null;
let serverUrlLockTimeout = null;

// Registration TOTP setup elements
const regTotpSetup = document.getElementById('regTotpSetup');
const regTotpQrImage = document.getElementById('regTotpQrImage');
const regTotpSecret = document.getElementById('regTotpSecret');
const regSecretKeyBox = document.getElementById('regSecretKeyBox');
const regToggleSecretBtn = document.getElementById('regToggleSecretBtn');
const regCopySecretBtn = document.getElementById('regCopySecretBtn');
const regTotpVerifyCode = document.getElementById('regTotpVerifyCode');
const regVerify2faBtn = document.getElementById('regVerify2faBtn');
const regSetupError = document.getElementById('regSetupError');
const regBackupCodes = document.getElementById('regBackupCodes');
const regBackupCodesList = document.getElementById('regBackupCodesList');
const regDismissBackupBtn = document.getElementById('regDismissBackupBtn');

// Confirm password field
const confirmPasswordField = document.getElementById('confirmPasswordField');
const confirmPasswordInput = document.getElementById('confirmPassword');

// Reset password elements
const forgotPasswordBtn = document.getElementById('forgotPasswordBtn');
const resetPasswordView = document.getElementById('resetPasswordView');
const resetStep1 = document.getElementById('resetStep1');
const resetStep2 = document.getElementById('resetStep2');
const resetEmail = document.getElementById('resetEmail');
const resetTotp = document.getElementById('resetTotp');
const resetVerifyBtn = document.getElementById('resetVerifyBtn');
const resetNewPassword = document.getElementById('resetNewPassword');
const resetConfirmPassword = document.getElementById('resetConfirmPassword');
const resetSubmitBtn = document.getElementById('resetSubmitBtn');
const resetCancelBtn = document.getElementById('resetCancelBtn');
const resetStep1Error = document.getElementById('resetStep1Error');
const resetStep2Error = document.getElementById('resetStep2Error');

const DEFAULT_SERVER_URL = '';

// ===== Server URL Binding Helpers =====

async function hashString(str) {
  const encoder = new TextEncoder();
  const data = encoder.encode(str);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function verifyServerUrlBinding() {
  const { boundServerUrlHash, serverUrl } = await getStorage(['boundServerUrlHash', 'serverUrl']);
  if (!boundServerUrlHash || !serverUrl) return true; // no binding yet
  const currentHash = await hashString(serverUrl);
  return currentHash === boundServerUrlHash;
}

// ===== Utility Functions =====

/**
 * Cross-browser sendMessage wrapper.
 * Firefox MV2 'chrome.runtime.sendMessage' is callback-based;
 * 'browser.runtime.sendMessage' returns a Promise.
 * Chrome MV3 'chrome.runtime.sendMessage' returns a Promise.
 */
function sendMessageToBackground(msg) {
  if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage) {
    return browser.runtime.sendMessage(msg);
  }
  return chrome.runtime.sendMessage(msg);
}

function showView(view) {
  [loginView, dashboardView, settingsView].forEach((v) => v.classList.add('hidden'));
  view.classList.remove('hidden');
}

function showError(el, message) {
  el.textContent = message;
  el.classList.remove('hidden');
}

function hideError(el) {
  el.classList.add('hidden');
}

function setLoading(btn, spinner, textEl, loading, text) {
  btn.disabled = loading;
  spinner.classList.toggle('hidden', !loading);
  textEl.textContent = text || textEl.textContent;
}

function resetTwoFactorState() {
  pendingTwoFactorChallenge = null;
  pendingRegistrationSetupToken = null;
  pendingRegistrationUser = null;
  pendingResetToken = null;
  twoFactorField.classList.add('hidden');
  twoFactorCode.value = '';
  document.getElementById('email').disabled = false;
  document.getElementById('password').disabled = false;
  nameField.classList.toggle('hidden', currentAuthMode === 'login');
  confirmPasswordField.classList.toggle('hidden', currentAuthMode === 'login');
  authTabs.classList.remove('hidden');
  authForm.classList.remove('hidden');
  authBtnText.textContent = currentAuthMode === 'login' ? 'Login' : 'Register';
  // Hide registration TOTP setup
  regTotpSetup.classList.add('hidden');
  regBackupCodes.classList.add('hidden');
  regSetupError.classList.add('hidden');
  // Hide reset password view
  resetPasswordView.classList.add('hidden');
  forgotPasswordBtn.classList.toggle('hidden', currentAuthMode !== 'login');
}

function addLogEntry(message, type = 'info') {
  syncLog.classList.remove('hidden');
  const entry = document.createElement('div');
  entry.className = `log-entry ${type}`;
  const time = new Date().toLocaleTimeString();
  const messageSpan = document.createElement('span');
  messageSpan.textContent = message;
  const timeSpan = document.createElement('span');
  timeSpan.className = 'log-time';
  timeSpan.textContent = time;
  entry.appendChild(messageSpan);
  entry.appendChild(timeSpan);
  logEntries.prepend(entry);

  // Keep only last 20 entries
  while (logEntries.children.length > 20) {
    logEntries.removeChild(logEntries.lastChild);
  }
}

function detectBrowser() {
  const ua = navigator.userAgent;
  if (ua.includes('Firefox')) return 'Firefox';
  if (ua.includes('Edg/')) return 'Edge';
  if (ua.includes('Brave')) return 'Brave';
  if (ua.includes('OPR') || ua.includes('Opera')) return 'Opera';
  if (ua.includes('Chrome')) return 'Chrome';
  if (ua.includes('Safari')) return 'Safari';
  return 'Unknown';
}

// ===== Storage Helpers =====

async function getStorage(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, resolve);
  });
}

async function setStorage(data) {
  return new Promise((resolve) => {
    chrome.storage.local.set(data, resolve);
  });
}

async function removeStorage(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.remove(keys, resolve);
  });
}

/**
 * Cross-browser bookmarks.getTree wrapper.
 * Firefox MV2 'chrome.bookmarks.getTree()' is callback-based (returns undefined).
 * 'browser.bookmarks.getTree()' returns a Promise.
 * Chrome MV3 'chrome.bookmarks.getTree()' returns a Promise.
 */
function getBookmarksTree() {
  if (typeof browser !== 'undefined' && browser.bookmarks && browser.bookmarks.getTree) {
    return browser.bookmarks.getTree();
  }
  // Chrome MV3: returns a Promise
  return chrome.bookmarks.getTree();
}

// ===== API Helpers =====

let refreshInFlight = null;

async function getServerUrl() {
  const { serverUrl } = await getStorage(['serverUrl']);
  if (!serverUrl) {
    throw new Error('Server URL not configured. Please set it in Settings.');
  }

  try {
    const parsed = new URL(serverUrl);
    const isLocalhost = parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1';
    if (!isLocalhost && parsed.protocol !== 'https:') {
      throw new Error('Insecure server URL. Please use HTTPS.');
    }
    return serverUrl;
  } catch (e) {
    throw e.message ? e : new Error('Invalid server URL configuration.');
  }
}

async function parseJsonResponse(response) {
  try {
    return await response.json();
  } catch {
    return {};
  }
}

async function refreshAccessToken() {
  if (refreshInFlight) {
    return refreshInFlight;
  }

  refreshInFlight = (async () => {
    const serverUrl = await getServerUrl();
    const { refreshToken } = await getStorage(['refreshToken']);

    if (!refreshToken) {
      throw new Error('No refresh token available. Please log in again.');
    }

    const response = await fetch(`${serverUrl}/api/auth/refresh`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ refreshToken }),
    });

    const data = await parseJsonResponse(response);
    if (!response.ok) {
      throw new Error(data.error || 'Session refresh failed. Please log in again.');
    }

    const nextAccessToken = data.accessToken || data.token;
    const nextRefreshToken = data.refreshToken || refreshToken;
    if (!nextAccessToken) {
      throw new Error('Refresh response did not include an access token.');
    }

    await setStorage({
      token: nextAccessToken,
      refreshToken: nextRefreshToken,
    });

    return nextAccessToken;
  })().finally(() => {
    refreshInFlight = null;
  });

  return refreshInFlight;
}

async function apiRequest(endpoint, options = {}, allowRefresh = true) {
  const serverUrl = await getServerUrl();
  const { token } = await getStorage(['token']);

  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const response = await fetch(`${serverUrl}/api${endpoint}`, {
    ...options,
    headers,
  });

  if (response.status === 401 && allowRefresh && endpoint !== '/auth/refresh') {
    try {
      await refreshAccessToken();
      return apiRequest(endpoint, options, false);
    } catch {
      await removeStorage(['token', 'refreshToken', 'user']);
      // Session is gone — show login view immediately
      resetTwoFactorState();
      showView(loginView);
      authForm.reset();
      hideError(authError);
      throw new Error('Session expired. Please log in again.');
    }
  }

  const data = await parseJsonResponse(response);

  if (!response.ok) {
    throw new Error(data.error || `Request failed (${response.status})`);
  }

  return data;
}

// ===== Auth =====

authTabs.addEventListener('click', (e) => {
  const tab = e.target.closest('.tab');
  if (!tab) return;

  currentAuthMode = tab.dataset.tab;
  resetTwoFactorState();
  authTabs.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
  tab.classList.add('active');

  nameField.classList.toggle('hidden', currentAuthMode === 'login');
  confirmPasswordField.classList.toggle('hidden', currentAuthMode === 'login');
  forgotPasswordBtn.classList.toggle('hidden', currentAuthMode !== 'login');
  authBtnText.textContent = currentAuthMode === 'login' ? 'Login' : 'Register';
  hideError(authError);
});

cancelTwoFactorBtn.addEventListener('click', () => {
  resetTwoFactorState();
  hideError(authError);
});

authForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  hideError(authError);

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const name = document.getElementById('name').value.trim();
  const confirmPw = confirmPasswordInput.value;
  const enteredTwoFactorCode = twoFactorCode.value.trim();

  if (!email || !password) {
    showError(authError, 'Please fill in all fields.');
    return;
  }

  // Validate confirm password on register
  if (currentAuthMode === 'register' && !pendingTwoFactorChallenge) {
    if (!confirmPw) {
      showError(authError, 'Please confirm your password.');
      return;
    }
    if (password !== confirmPw) {
      showError(authError, 'Passwords do not match.');
      return;
    }
  }

  setLoading(authSubmit, authSpinner, authBtnText, true);

  try {
    let endpoint = currentAuthMode === 'login' ? '/auth/login' : '/auth/register';
    let body = { email, password };

    if (pendingTwoFactorChallenge) {
      endpoint = '/auth/2fa/verify-login';
      body = {
        challengeToken: pendingTwoFactorChallenge,
        totpCode: enteredTwoFactorCode,
      };

      if (!enteredTwoFactorCode) {
        throw new Error('Please enter your authenticator code.');
      }
    } else if (currentAuthMode === 'register' && name) {
      body.name = name;
    }

    const data = await apiRequest(endpoint, {
      method: 'POST',
      body: JSON.stringify(body),
    });

    if (data.requiresTwoFactor) {
      pendingTwoFactorChallenge = data.challengeToken;
      twoFactorField.classList.remove('hidden');
      authTabs.classList.add('hidden');
      nameField.classList.add('hidden');
      document.getElementById('email').disabled = true;
      document.getElementById('password').disabled = true;
      authBtnText.textContent = 'Verify 2FA';
      twoFactorCode.focus();
      return;
    }

    // Registration returns requiresTotpSetup — show QR setup
    if (data.requiresTotpSetup) {
      pendingRegistrationSetupToken = data.setupToken;
      authForm.classList.add('hidden');
      authTabs.classList.add('hidden');

      // Show QR code
      if (data.qrDataUrl) {
        regTotpQrImage.src = data.qrDataUrl;
        regTotpQrImage.classList.remove('hidden');
      }
      regTotpSecret.textContent = data.secret;
      regSecretKeyBox.classList.add('hidden');
      regTotpSetup.classList.remove('hidden');
      regTotpVerifyCode.value = '';
      regTotpVerifyCode.focus();
      return;
    }

    // Save auth data + bind the server URL to this session
    const loginServerUrl = await getServerUrl();
    const boundHash = await hashString(loginServerUrl);
    await setStorage({
      token: data.accessToken || data.token,
      refreshToken: data.refreshToken || null,
      user: data.user,
      boundServerUrlHash: boundHash,
    });

    resetTwoFactorState();

    showDashboard(data.user);
  } catch (err) {
    showError(authError, err.message);
  } finally {
    setLoading(authSubmit, authSpinner, authBtnText, false, currentAuthMode === 'login' ? 'Login' : 'Register');
  }
});

// ===== Dashboard =====

async function showDashboard(user) {
  showView(dashboardView);

  userEmail.textContent = user.email;
  userAvatar.textContent = (user.name || user.email)[0].toUpperCase();

  const browser = detectBrowser();
  browserNameEl.textContent = browser;
  await setStorage({ browserName: browser });

  await refreshStats();
}

async function refreshStats() {
  try {
    // Get local bookmark count
    const tree = await getBookmarksTree();
    const count = countBookmarks(tree);
    localCount.textContent = count;

    // Get server count
    const { lastSyncTime } = await getStorage(['lastSyncTime']);
    if (lastSyncTime) {
      syncStatus.textContent = `Last synced: ${new Date(lastSyncTime).toLocaleString()}`;
    }

    try {
      const data = await apiRequest('/bookmarks');
      serverCount.textContent = data.bookmarks.length;
    } catch {
      serverCount.textContent = '?';
    }
  } catch (err) {
    console.error('Failed to refresh stats:', err);
  }
}

function countBookmarks(nodes) {
  let count = 0;
  for (const node of nodes) {
    if (node.url) count++;
    if (node.children) count += countBookmarks(node.children);
  }
  return count;
}

// ===== Sync Actions =====

async function ensureServerUrlBound() {
  const valid = await verifyServerUrlBinding();
  if (!valid) {
    throw new Error('Server URL has changed since login. Please log out and log in again to sync.');
  }
}

syncNowBtn.addEventListener('click', async () => {
  setLoading(syncNowBtn, syncSpinner, syncBtnText, true, 'Syncing...');
  try {
    await ensureServerUrlBound();
    // Send message to background script to perform sync
    const response = await sendMessageToBackground({ action: 'sync' });
    if (response?.success) {
      addLogEntry(`Synced: ${response.created || 0} new, ${response.updated || 0} updated`, 'success');
      await setStorage({ lastSyncTime: new Date().toISOString() });
      await refreshStats();
    } else {
      const errMsg = response?.error || response?.message || 'Sync failed (no details)';
      throw new Error(errMsg);
    }
  } catch (err) {
    addLogEntry(`Error: ${err.message}`, 'error');
    console.error('LinkNest sync error:', err);
  } finally {
    setLoading(syncNowBtn, syncSpinner, syncBtnText, false, 'Sync Now');
  }
});

pushBtn.addEventListener('click', async () => {
  pushBtn.disabled = true;
  try {
    await ensureServerUrlBound();
    const response = await sendMessageToBackground({ action: 'push' });
    if (response?.success) {
      addLogEntry(`Pushed ${response.count || 0} bookmarks to cloud`, 'success');
      await refreshStats();
    } else {
      const errMsg = response?.error || response?.message || 'Push failed (no details)';
      throw new Error(errMsg);
    }
  } catch (err) {
    addLogEntry(`Push error: ${err.message}`, 'error');
    console.error('LinkNest push error:', err);
  } finally {
    pushBtn.disabled = false;
  }
});

pullBtn.addEventListener('click', async () => {
  pullBtn.disabled = true;
  try {
    await ensureServerUrlBound();
    const response = await sendMessageToBackground({ action: 'pull' });
    if (response?.success) {
      addLogEntry(`Pulled ${response.count || 0} bookmarks from cloud`, 'success');
      await refreshStats();
    } else {
      const errMsg = response?.error || response?.message || 'Pull failed (no details)';
      throw new Error(errMsg);
    }
  } catch (err) {
    addLogEntry(`Pull error: ${err.message}`, 'error');
    console.error('LinkNest pull error:', err);
  } finally {
    pullBtn.disabled = false;
  }
});

// ===== Organize =====

let pendingOrganizeData = null;

organizeBtn.addEventListener('click', async () => {
  setLoading(organizeBtn, organizeSpinner, organizeBtnText, true, 'Analyzing...');
  organizePreview.classList.add('hidden');
  pendingOrganizeData = null;

  try {
    await ensureServerUrlBound();

    // Get categorization from background (which has local bookmarks + calls server)
    const response = await sendMessageToBackground({ action: 'categorize' });

    if (!response?.success) {
      throw new Error(response?.error || 'Categorization failed');
    }

    pendingOrganizeData = response.categories;
    const stats = response.stats;

    // Show stats
    const parts = [`${stats.total} bookmarks analyzed`];
    if (stats.byDomain > 0) parts.push(`${stats.byDomain} by domain`);
    if (stats.byAI > 0) parts.push(`${stats.byAI} by AI`);
    if (stats.uncategorized > 0) parts.push(`${stats.uncategorized} uncategorized`);
    if (!stats.aiEnabled) parts.push('AI not configured — domain-only mode');
    organizeStats.textContent = parts.join(' · ');

    // Build category list
    organizeCategories.innerHTML = '';
    const createFolderIcon = () => {
      const svgNs = 'http://www.w3.org/2000/svg';
      const svg = document.createElementNS(svgNs, 'svg');
      svg.setAttribute('width', '14');
      svg.setAttribute('height', '14');
      svg.setAttribute('viewBox', '0 0 24 24');
      svg.setAttribute('fill', 'none');
      svg.setAttribute('stroke', 'currentColor');
      svg.setAttribute('stroke-width', '2');

      const path = document.createElementNS(svgNs, 'path');
      path.setAttribute('d', 'M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z');
      svg.appendChild(path);
      return svg;
    };

    for (const [category, bookmarks] of Object.entries(pendingOrganizeData)) {
      const row = document.createElement('div');
      row.className = 'organize-category';

      const nameEl = document.createElement('div');
      nameEl.className = 'cat-name';
      const iconEl = document.createElement('span');
      iconEl.className = 'cat-icon';
      iconEl.appendChild(createFolderIcon());
      const labelEl = document.createElement('span');
      labelEl.textContent = category;
      nameEl.appendChild(iconEl);
      nameEl.appendChild(labelEl);

      const countEl = document.createElement('span');
      countEl.className = 'cat-count';
      countEl.textContent = bookmarks.length;

      row.appendChild(nameEl);
      row.appendChild(countEl);

      // Expandable items list
      const itemsEl = document.createElement('div');
      itemsEl.className = 'cat-items';
      const maxShow = 8;
      bookmarks.slice(0, maxShow).forEach((bm) => {
        const item = document.createElement('div');
        item.className = 'cat-item';
        item.textContent = bm.title || bm.url;
        item.title = bm.url;
        itemsEl.appendChild(item);
      });
      if (bookmarks.length > maxShow) {
        const more = document.createElement('div');
        more.className = 'cat-item';
        more.textContent = `... and ${bookmarks.length - maxShow} more`;
        more.style.fontStyle = 'italic';
        itemsEl.appendChild(more);
      }

      row.addEventListener('click', () => {
        row.classList.toggle('expanded');
      });

      const wrapper = document.createElement('div');
      wrapper.appendChild(row);
      wrapper.appendChild(itemsEl);
      organizeCategories.appendChild(wrapper);
    }

    organizePreview.classList.remove('hidden');
    addLogEntry(`Categorized ${stats.total} bookmarks into ${Object.keys(pendingOrganizeData).length} folders`, 'info');
  } catch (err) {
    addLogEntry(`Organize error: ${err.message}`, 'error');
    console.error('LinkNest organize error:', err);
  } finally {
    setLoading(organizeBtn, organizeSpinner, organizeBtnText, false, 'Organize');
  }
});

organizeApplyBtn.addEventListener('click', async () => {
  if (!pendingOrganizeData) return;

  organizeApplyBtn.disabled = true;
  organizeCancelBtn.disabled = true;

  try {
    await ensureServerUrlBound();

    const response = await sendMessageToBackground({
      action: 'applyOrganize',
      categories: pendingOrganizeData,
    });

    if (!response?.success) {
      throw new Error(response?.error || 'Failed to apply organization');
    }

    addLogEntry(`Organized: moved ${response.moved || 0} bookmarks into ${response.foldersCreated || 0} folders`, 'success');
    organizePreview.classList.add('hidden');
    pendingOrganizeData = null;

    // Trigger sync after organizing
    try {
      const syncResp = await sendMessageToBackground({ action: 'sync' });
      if (syncResp?.success) {
        addLogEntry('Synced after organize', 'success');
      }
    } catch {}

    await refreshStats();
  } catch (err) {
    addLogEntry(`Apply error: ${err.message}`, 'error');
    console.error('LinkNest apply organize error:', err);
  } finally {
    organizeApplyBtn.disabled = false;
    organizeCancelBtn.disabled = false;
  }
});

organizeCancelBtn.addEventListener('click', () => {
  organizePreview.classList.add('hidden');
  pendingOrganizeData = null;
  addLogEntry('Organize cancelled', 'info');
});

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ===== Server URL Lock =====

function lockServerUrl() {
  const serverUrlInput = document.getElementById('serverUrl');
  serverUrlInput.disabled = true;
  serverUrlInput.classList.add('input-locked');
  lockIconLocked.classList.remove('hidden');
  lockIconUnlocked.classList.add('hidden');
  serverUrlLockBtn.title = 'Unlock to edit';
  if (serverUrlLockTimeout) {
    clearTimeout(serverUrlLockTimeout);
    serverUrlLockTimeout = null;
  }
}

function unlockServerUrl() {
  const serverUrlInput = document.getElementById('serverUrl');
  serverUrlInput.disabled = false;
  serverUrlInput.classList.remove('input-locked');
  lockIconLocked.classList.add('hidden');
  lockIconUnlocked.classList.remove('hidden');
  serverUrlLockBtn.title = 'Click to lock';
  serverUrlInput.focus();
  // Auto-lock after 30 seconds
  if (serverUrlLockTimeout) clearTimeout(serverUrlLockTimeout);
  serverUrlLockTimeout = setTimeout(lockServerUrl, 30000);
}

serverUrlLockBtn.addEventListener('click', async () => {
  const serverUrlInput = document.getElementById('serverUrl');
  if (serverUrlInput.disabled) {
    // Locked → require TOTP to unlock
    const { token } = await getStorage(['token']);
    if (token) {
      // Show TOTP verification inline
      serverUrlUnlockVerify.classList.remove('hidden');
      hideError(serverUrlUnlockError);
      serverUrlUnlockInput.value = '';
      serverUrlUnlockInput.focus();
    } else {
      // Not logged in — unlock freely
      unlockServerUrl();
    }
  } else {
    lockServerUrl();
  }
});

serverUrlUnlockBtn.addEventListener('click', async () => {
  const code = serverUrlUnlockInput.value.trim();
  if (!code) {
    showError(serverUrlUnlockError, 'Enter your authenticator code.');
    return;
  }
  serverUrlUnlockBtn.disabled = true;
  hideError(serverUrlUnlockError);
  try {
    await apiRequest('/auth/verify-action', {
      method: 'POST',
      body: JSON.stringify({ totpCode: code }),
    });
    serverUrlUnlockVerify.classList.add('hidden');
    unlockServerUrl();
  } catch (err) {
    showError(serverUrlUnlockError, err.message);
  } finally {
    serverUrlUnlockBtn.disabled = false;
  }
});

serverUrlUnlockCancelBtn.addEventListener('click', () => {
  serverUrlUnlockVerify.classList.add('hidden');
  serverUrlUnlockInput.value = '';
  hideError(serverUrlUnlockError);
});

// ===== Clear Server & Re-push =====

clearServerBtn.addEventListener('click', async () => {
  // Show verification section instead of confirm()
  clearServerVerify.classList.remove('hidden');
  clearServerBtn.classList.add('hidden');
  hideError(clearVerifyError);
  clearVerifyInput.value = '';

  // Check if 2FA is enabled to show the right input
  try {
    const data = await apiRequest('/auth/2fa/status');
    const has2FA = data.twoFactor && data.twoFactor.enabled;

    if (has2FA) {
      clearVerifyInput.type = 'text';
      clearVerifyInput.placeholder = '123456';
      clearVerifyInput.inputMode = 'numeric';
      clearVerifyInput.maxLength = 6;
      clearVerifyPrompt.textContent = 'Enter your authenticator code:';
    } else {
      clearVerifyInput.type = 'password';
      clearVerifyInput.placeholder = 'Enter your password';
      clearVerifyInput.inputMode = '';
      clearVerifyInput.maxLength = 128;
      clearVerifyPrompt.textContent = 'Enter your password to continue:';
    }
  } catch {
    // Fallback to password
    clearVerifyInput.type = 'password';
    clearVerifyInput.placeholder = 'Enter your password';
    clearVerifyPrompt.textContent = 'Enter your password to continue:';
  }

  clearVerifyInput.focus();
});

clearVerifyBtn.addEventListener('click', async () => {
  const value = clearVerifyInput.value.trim();
  if (!value) {
    showError(clearVerifyError, 'Please enter your verification.');
    return;
  }

  clearVerifyBtn.disabled = true;
  hideError(clearVerifyError);

  try {
    // Build verify body based on input type
    const is2FA = clearVerifyInput.type === 'text';
    const body = is2FA ? { totpCode: value } : { password: value };

    // Step 1: Verify identity and get action token
    const verifyData = await apiRequest('/auth/verify-action', {
      method: 'POST',
      body: JSON.stringify(body),
    });

    const actionToken = verifyData.actionToken;

    // Step 2: Delete all server bookmarks with verified action token
    await apiRequest('/bookmarks', {
      method: 'DELETE',
      headers: { 'X-Action-Token': actionToken },
    });
    addLogEntry('Server bookmarks cleared', 'success');

    // Step 3: Clear local sync state
    await setStorage({ lastSyncTime: null, lastLocalBookmarkHashes: [] });

    // Step 4: Push fresh bookmarks
    const response = await sendMessageToBackground({ action: 'push' });
    if (response?.success) {
      addLogEntry(`Re-pushed ${response.count || 0} bookmarks to cloud`, 'success');
      await refreshStats();
    } else {
      throw new Error(response?.error || 'Push failed');
    }

    // Done — hide verification, show button
    clearServerVerify.classList.add('hidden');
    clearServerBtn.classList.remove('hidden');
  } catch (err) {
    showError(clearVerifyError, err.message);
  } finally {
    clearVerifyBtn.disabled = false;
  }
});

clearVerifyCancelBtn.addEventListener('click', () => {
  clearServerVerify.classList.add('hidden');
  clearServerBtn.classList.remove('hidden');
  hideError(clearVerifyError);
  clearVerifyInput.value = '';
});

// ===== Logout =====

async function performLogout() {
  const { token, refreshToken } = await getStorage(['token', 'refreshToken']);

  try {
    const serverUrl = await getServerUrl();
    if (token) {
      await fetch(`${serverUrl}/api/auth/logout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ refreshToken }),
      });
    }
  } catch {
    // Ignore network errors on logout cleanup
  }

  await removeStorage(['token', 'refreshToken', 'user', 'lastSyncTime', 'lastLocalBookmarkHashes', 'boundServerUrlHash']);
  resetTwoFactorState();
  showView(loginView);
  authForm.reset();
  hideError(authError);
}

logoutBtn.addEventListener('click', async () => {
  // Require TOTP verification before logout
  logoutVerify.classList.remove('hidden');
  logoutBtn.classList.add('hidden');
  hideError(logoutVerifyError);
  logoutVerifyInput.value = '';
  logoutVerifyInput.focus();
});

logoutVerifyBtn.addEventListener('click', async () => {
  const code = logoutVerifyInput.value.trim();
  if (!code) {
    showError(logoutVerifyError, 'Enter your authenticator code.');
    return;
  }
  logoutVerifyBtn.disabled = true;
  hideError(logoutVerifyError);
  try {
    await apiRequest('/auth/verify-action', {
      method: 'POST',
      body: JSON.stringify({ totpCode: code }),
    });
    logoutVerify.classList.add('hidden');
    logoutBtn.classList.remove('hidden');
    await performLogout();
  } catch (err) {
    showError(logoutVerifyError, err.message);
  } finally {
    logoutVerifyBtn.disabled = false;
  }
});

logoutVerifyCancelBtn.addEventListener('click', () => {
  logoutVerify.classList.add('hidden');
  logoutBtn.classList.remove('hidden');
  logoutVerifyInput.value = '';
  hideError(logoutVerifyError);
});

// ===== Settings =====

settingsBtn.addEventListener('click', async () => {
  const { autoSync, syncInterval, serverUrl, token } = await getStorage([
    'autoSync',
    'syncInterval',
    'serverUrl',
    'token',
  ]);

  document.getElementById('autoSync').checked = autoSync !== false;
  document.getElementById('syncInterval').value = syncInterval || '15';
  document.getElementById('serverUrl').value = serverUrl || '';

  // Lock server URL when logged in
  if (token) {
    serverUrlLockBtn.classList.remove('hidden');
    lockServerUrl();
  } else {
    serverUrlLockBtn.classList.add('hidden');
    document.getElementById('serverUrl').disabled = false;
    document.getElementById('serverUrl').classList.remove('input-locked');
  }

  showView(settingsView);

  // Load 2FA status (async, non-blocking)
  refresh2faStatus();
});

backBtn.addEventListener('click', async () => {
  const { token, user } = await getStorage(['token', 'user']);
  if (token && user) {
    showDashboard(user);
  } else {
    showView(loginView);
  }
});

saveSettingsBtn.addEventListener('click', async () => {
  const autoSync = document.getElementById('autoSync').checked;
  const syncInterval = document.getElementById('syncInterval').value;
  const serverUrl = document.getElementById('serverUrl').value.replace(/\/+$/, '');

  try {
    const parsed = new URL(serverUrl);
    const isLocalhost = parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1';
    if (!isLocalhost && parsed.protocol !== 'https:') {
      showError(authError, 'Server URL must use HTTPS (except localhost).');
      return;
    }
  } catch {
    showError(authError, 'Please enter a valid server URL.');
    return;
  }

  await setStorage({ autoSync, syncInterval, serverUrl });

  // Re-lock server URL after save
  const { token: savedToken } = await getStorage(['token']);
  if (savedToken) {
    lockServerUrl();
  }

  // Notify background to update alarm
  sendMessageToBackground({
    action: 'updateSettings',
    settings: { autoSync, syncInterval, serverUrl },
  });

  // Go back
  const { token, user } = await getStorage(['token', 'user']);
  if (token && user) {
    showDashboard(user);
  } else {
    showView(loginView);
  }
});

// ===== 2FA Setup =====

const securitySection = document.getElementById('securitySection');
const twoFactorBadge = document.getElementById('twoFactorBadge');
const twoFactorEnableSection = document.getElementById('twoFactorEnableSection');
const twoFactorDisableSection = document.getElementById('twoFactorDisableSection');
const twoFactorSetupFlow = document.getElementById('twoFactorSetupFlow');
const backupCodesSection = document.getElementById('backupCodesSection');
const backupCodesList = document.getElementById('backupCodesList');
const backupCodesRemaining = document.getElementById('backupCodesRemaining');
const totpSecret = document.getElementById('totpSecret');
const totpQrImage = document.getElementById('totpQrImage');
const secretKeyBox = document.getElementById('secretKeyBox');
const toggleSecretBtn = document.getElementById('toggleSecretBtn');
const totpVerifyCode = document.getElementById('totpVerifyCode');
const setup2faBtn = document.getElementById('setup2faBtn');
const verify2faBtn = document.getElementById('verify2faBtn');
const disable2faBtn = document.getElementById('disable2faBtn');
const copySecretBtn = document.getElementById('copySecretBtn');
const dismissBackupCodesBtn = document.getElementById('dismissBackupCodesBtn');
const setup2faError = document.getElementById('setup2faError');
const disable2faVerify = document.getElementById('disable2faVerify');
const disable2faPrompt = document.getElementById('disable2faPrompt');
const disable2faInput = document.getElementById('disable2faInput');
const disable2faConfirmBtn = document.getElementById('disable2faConfirmBtn');
const disable2faCancelBtn = document.getElementById('disable2faCancelBtn');
const disable2faError = document.getElementById('disable2faError');

/**
 * Load 2FA status from server and update the Security section in Settings.
 * Only shows the section when the user is logged in.
 */
async function refresh2faStatus() {
  const { token } = await getStorage(['token']);
  if (!token) {
    securitySection.classList.add('hidden');
    return;
  }

  try {
    const data = await apiRequest('/auth/2fa/status');
    const info = data.twoFactor;

    securitySection.classList.remove('hidden');

    // Reset sub-sections
    twoFactorSetupFlow.classList.add('hidden');
    backupCodesSection.classList.add('hidden');
    setup2faError.classList.add('hidden');
    totpVerifyCode.value = '';

    if (info.enabled) {
      twoFactorBadge.textContent = 'On';
      twoFactorBadge.className = 'badge badge-on';
      twoFactorEnableSection.classList.add('hidden');
      twoFactorDisableSection.classList.remove('hidden');
      backupCodesRemaining.textContent = info.backupCodesCount ?? 0;
    } else {
      twoFactorBadge.textContent = 'Off';
      twoFactorBadge.className = 'badge badge-off';
      twoFactorEnableSection.classList.remove('hidden');
      twoFactorDisableSection.classList.add('hidden');
    }
  } catch {
    // Not logged in or network error — hide section
    securitySection.classList.add('hidden');
  }
}

// Start 2FA setup: request secret + QR from server
function createEyeToggleIcon(isHidden) {
  const svgNs = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNs, 'svg');
  svg.setAttribute('width', '14');
  svg.setAttribute('height', '14');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '2');

  if (isHidden) {
    const path1 = document.createElementNS(svgNs, 'path');
    path1.setAttribute('d', 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z');
    const circle = document.createElementNS(svgNs, 'circle');
    circle.setAttribute('cx', '12');
    circle.setAttribute('cy', '12');
    circle.setAttribute('r', '3');
    svg.appendChild(path1);
    svg.appendChild(circle);
  } else {
    const path1 = document.createElementNS(svgNs, 'path');
    path1.setAttribute('d', 'M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24');
    const line = document.createElementNS(svgNs, 'line');
    line.setAttribute('x1', '1');
    line.setAttribute('y1', '1');
    line.setAttribute('x2', '23');
    line.setAttribute('y2', '23');
    svg.appendChild(path1);
    svg.appendChild(line);
  }

  return svg;
}

function setSecretToggleButton(buttonEl, isHidden) {
  const label = document.createTextNode(isHidden ? ' Show secret key' : ' Hide secret key');
  buttonEl.replaceChildren(createEyeToggleIcon(isHidden), label);
}

setup2faBtn.addEventListener('click', async () => {
  setup2faBtn.disabled = true;
  setup2faError.classList.add('hidden');

  try {
    const data = await apiRequest('/auth/2fa/totp/setup/start', { method: 'POST' });

    // Show QR code
    if (data.qrDataUrl) {
      totpQrImage.src = data.qrDataUrl;
      totpQrImage.classList.remove('hidden');
    } else {
      totpQrImage.classList.add('hidden');
    }

    // Set secret (hidden by default)
    totpSecret.textContent = data.secret;
    secretKeyBox.classList.add('hidden');
    setSecretToggleButton(toggleSecretBtn, true);

    twoFactorSetupFlow.classList.remove('hidden');
    twoFactorEnableSection.classList.add('hidden');
    totpVerifyCode.focus();
  } catch (err) {
    showError(setup2faError, err.message);
  } finally {
    setup2faBtn.disabled = false;
  }
});

// Toggle secret key visibility
toggleSecretBtn.addEventListener('click', () => {
  const isHidden = secretKeyBox.classList.contains('hidden');
  if (isHidden) {
    secretKeyBox.classList.remove('hidden');
    setSecretToggleButton(toggleSecretBtn, false);
  } else {
    secretKeyBox.classList.add('hidden');
    setSecretToggleButton(toggleSecretBtn, true);
  }
});

// Copy secret to clipboard
copySecretBtn.addEventListener('click', async () => {
  const secret = totpSecret.textContent;
  if (!secret || secret === '—') return;

  try {
    await navigator.clipboard.writeText(secret);
    copySecretBtn.title = 'Copied!';
    setTimeout(() => { copySecretBtn.title = 'Copy secret'; }, 2000);
  } catch {
    // Fallback: select the text
    const range = document.createRange();
    range.selectNodeContents(totpSecret);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }
});

// Verify TOTP code and enable 2FA
verify2faBtn.addEventListener('click', async () => {
  const code = totpVerifyCode.value.trim();
  if (!code) {
    showError(setup2faError, 'Enter the 6-digit code from your authenticator.');
    return;
  }

  verify2faBtn.disabled = true;
  setup2faError.classList.add('hidden');

  try {
    const data = await apiRequest('/auth/2fa/totp/setup/verify', {
      method: 'POST',
      body: JSON.stringify({ code }),
    });

    // Show backup codes
    twoFactorSetupFlow.classList.add('hidden');
    backupCodesSection.classList.remove('hidden');
    backupCodesList.innerHTML = '';
    for (const bc of data.backupCodes) {
      const span = document.createElement('span');
      span.textContent = bc;
      backupCodesList.appendChild(span);
    }

    // Update badge
    twoFactorBadge.textContent = 'On';
    twoFactorBadge.className = 'badge badge-on';
  } catch (err) {
    showError(setup2faError, err.message);
  } finally {
    verify2faBtn.disabled = false;
  }
});

// Dismiss backup codes after user confirms they saved them
dismissBackupCodesBtn.addEventListener('click', async () => {
  backupCodesSection.classList.add('hidden');
  // 2FA is now active — after enabling, all refresh tokens are revoked
  // so the user needs to re-login. Force re-login.
  await removeStorage(['token', 'refreshToken', 'user', 'lastSyncTime', 'lastLocalBookmarkHashes']);
  resetTwoFactorState();
  showView(loginView);
  authForm.reset();
  hideError(authError);
  addLogEntry('2FA enabled — please log in again', 'success');
});

// Disable 2FA — show verification inline first
disable2faBtn.addEventListener('click', () => {
  disable2faBtn.classList.add('hidden');
  disable2faVerify.classList.remove('hidden');
  disable2faInput.value = '';
  hideError(disable2faError);
  disable2faInput.focus();
});

disable2faCancelBtn.addEventListener('click', () => {
  disable2faVerify.classList.add('hidden');
  disable2faBtn.classList.remove('hidden');
  disable2faInput.value = '';
  hideError(disable2faError);
});

disable2faConfirmBtn.addEventListener('click', async () => {
  const code = disable2faInput.value.trim();
  if (!code) {
    showError(disable2faError, 'Enter your authenticator code to continue.');
    return;
  }

  disable2faConfirmBtn.disabled = true;
  hideError(disable2faError);

  try {
    await apiRequest('/auth/2fa/disable', {
      method: 'POST',
      body: JSON.stringify({ totpCode: code }),
    });

    // 2FA disabled — all refresh tokens revoked, force re-login
    await removeStorage(['token', 'refreshToken', 'user', 'lastSyncTime', 'lastLocalBookmarkHashes']);
    resetTwoFactorState();
    showView(loginView);
    authForm.reset();
    hideError(authError);
    addLogEntry('2FA disabled — please log in again', 'success');
  } catch (err) {
    showError(disable2faError, err.message);
  } finally {
    disable2faConfirmBtn.disabled = false;
  }
});

// ===== Registration TOTP Setup =====

regToggleSecretBtn.addEventListener('click', () => {
  const isHidden = regSecretKeyBox.classList.contains('hidden');
  if (isHidden) {
    regSecretKeyBox.classList.remove('hidden');
    setSecretToggleButton(regToggleSecretBtn, false);
  } else {
    regSecretKeyBox.classList.add('hidden');
    setSecretToggleButton(regToggleSecretBtn, true);
  }
});

regCopySecretBtn.addEventListener('click', async () => {
  const secret = regTotpSecret.textContent;
  if (!secret || secret === '—') return;
  try {
    await navigator.clipboard.writeText(secret);
    regCopySecretBtn.title = 'Copied!';
    setTimeout(() => { regCopySecretBtn.title = 'Copy secret'; }, 2000);
  } catch {
    const range = document.createRange();
    range.selectNodeContents(regTotpSecret);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }
});

regVerify2faBtn.addEventListener('click', async () => {
  const code = regTotpVerifyCode.value.trim();
  if (!code) {
    regSetupError.textContent = 'Enter the 6-digit code from your authenticator.';
    regSetupError.classList.remove('hidden');
    return;
  }

  regVerify2faBtn.disabled = true;
  regSetupError.classList.add('hidden');

  try {
    const data = await apiRequest('/auth/register/verify-totp', {
      method: 'POST',
      body: JSON.stringify({
        setupToken: pendingRegistrationSetupToken,
        code,
      }),
    });

    // Save auth data + bind server URL to this session
    pendingRegistrationUser = data.user;
    const regServerUrl = await getServerUrl();
    const regBoundHash = await hashString(regServerUrl);
    await setStorage({
      token: data.accessToken,
      refreshToken: data.refreshToken,
      user: data.user,
      boundServerUrlHash: regBoundHash,
    });

    // Show backup codes
    regTotpSetup.classList.add('hidden');
    regBackupCodes.classList.remove('hidden');
    regBackupCodesList.innerHTML = '';
    for (const bc of data.backupCodes) {
      const span = document.createElement('span');
      span.textContent = bc;
      regBackupCodesList.appendChild(span);
    }
  } catch (err) {
    regSetupError.textContent = err.message;
    regSetupError.classList.remove('hidden');
  } finally {
    regVerify2faBtn.disabled = false;
  }
});

regDismissBackupBtn.addEventListener('click', async () => {
  regBackupCodes.classList.add('hidden');
  resetTwoFactorState();
  if (pendingRegistrationUser) {
    showDashboard(pendingRegistrationUser);
    pendingRegistrationUser = null;
  } else {
    const { user } = await getStorage(['user']);
    if (user) showDashboard(user);
  }
});

// ===== Reset Password Flow =====

forgotPasswordBtn.addEventListener('click', () => {
  authForm.classList.add('hidden');
  authTabs.classList.add('hidden');
  forgotPasswordBtn.classList.add('hidden');
  resetPasswordView.classList.remove('hidden');
  resetStep1.classList.remove('hidden');
  resetStep2.classList.add('hidden');
  hideError(resetStep1Error);
  hideError(resetStep2Error);
  resetEmail.value = document.getElementById('email').value.trim();
  resetTotp.value = '';
  pendingResetToken = null;
  resetEmail.focus();
});

resetCancelBtn.addEventListener('click', () => {
  resetPasswordView.classList.add('hidden');
  authForm.classList.remove('hidden');
  authTabs.classList.remove('hidden');
  forgotPasswordBtn.classList.remove('hidden');
  pendingResetToken = null;
  hideError(authError);
});

resetVerifyBtn.addEventListener('click', async () => {
  const email = resetEmail.value.trim();
  const totp = resetTotp.value.trim();
  if (!email || !totp) {
    showError(resetStep1Error, 'Please enter your email and authenticator code.');
    return;
  }
  resetVerifyBtn.disabled = true;
  hideError(resetStep1Error);
  try {
    const serverUrl = await getServerUrl();
    const response = await fetch(`${serverUrl}/api/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, totpCode: totp }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || 'Verification failed.');
    }
    if (data.verified && data.resetToken) {
      pendingResetToken = data.resetToken;
      resetStep1.classList.add('hidden');
      resetStep2.classList.remove('hidden');
      resetNewPassword.value = '';
      resetConfirmPassword.value = '';
      hideError(resetStep2Error);
      resetNewPassword.focus();
    }
  } catch (err) {
    showError(resetStep1Error, err.message);
  } finally {
    resetVerifyBtn.disabled = false;
  }
});

resetSubmitBtn.addEventListener('click', async () => {
  const newPw = resetNewPassword.value;
  const confirmPw = resetConfirmPassword.value;
  if (!newPw) {
    showError(resetStep2Error, 'Please enter a new password.');
    return;
  }
  if (newPw !== confirmPw) {
    showError(resetStep2Error, 'Passwords do not match.');
    return;
  }
  if (!pendingResetToken) {
    showError(resetStep2Error, 'Reset session expired. Please start over.');
    return;
  }
  resetSubmitBtn.disabled = true;
  hideError(resetStep2Error);
  try {
    const serverUrl = await getServerUrl();
    const response = await fetch(`${serverUrl}/api/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        newPassword: newPw,
        confirmPassword: confirmPw,
        resetToken: pendingResetToken,
      }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || 'Password reset failed.');
    }
    // Success — go back to login
    pendingResetToken = null;
    resetPasswordView.classList.add('hidden');
    authForm.classList.remove('hidden');
    authTabs.classList.remove('hidden');
    forgotPasswordBtn.classList.remove('hidden');
    showError(authError, '');
    // Show success message in auth error field (green-ish style not available, use text)
    authError.textContent = data.message || 'Password reset successfully. Please log in.';
    authError.classList.remove('hidden');
    authError.style.color = '#22c55e';
    setTimeout(() => { authError.style.color = ''; }, 5000);
  } catch (err) {
    showError(resetStep2Error, err.message);
  } finally {
    resetSubmitBtn.disabled = false;
  }
});

// ===== Init =====

(async () => {
  const { token, user } = await getStorage(['token', 'user']);

  if (token && user) {
    // Verify token is still valid
    try {
      const data = await apiRequest('/auth/me');
      showDashboard(data.user);
    } catch {
      // Token expired, show login
      await removeStorage(['token', 'refreshToken', 'user']);
      resetTwoFactorState();
      showView(loginView);
    }
  } else {
    resetTwoFactorState();
    showView(loginView);
  }
})();
