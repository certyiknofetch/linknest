<!-- PNG icons need to be generated from icon.svg -->
<!-- Use any SVG-to-PNG converter or run: -->
<!-- npx svg-png-converter --input icons/icon.svg --output icons/ --sizes 16,48,128 -->
<!-- For now, the extension will work without icons (shows default) -->
